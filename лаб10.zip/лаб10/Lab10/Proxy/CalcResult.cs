namespace Lab10.Proxy
{
    public sealed class CalcResult
    {
        public bool Success { get; }
        public double Value { get; }
        public string Message { get; }

        private CalcResult(bool success, double value, string message)
        {
            Success = success;
            Value = value;
            Message = message ?? string.Empty;
        }

        public static CalcResult Ok(double value, string message = "")
            => new CalcResult(true, value, message);

        public static CalcResult Fail(string message)
            => new CalcResult(false, 0, message);
    }
}
