using System;
using System.Globalization;

namespace Lab10.Proxy
{
  
 
    public sealed class CalculatorProxy : ICalculatorService
    {
        private readonly ICalculator _realCalculator;

     
        private const double MinValueAllowed = -1_000_000_000d;
        private const double MaxValueAllowed =  1_000_000_000d;

        public CalculatorProxy(ICalculator realCalculator)
        {
            _realCalculator = realCalculator ?? throw new ArgumentNullException(nameof(realCalculator));
        }

        public CalcResult Calculate(string aText, string bText, CalcOperation operation)
        {
            if (!TryParseNumber(aText, out var a))
                return CalcResult.Fail("Перше число введено некоректно.");

            if (!TryParseNumber(bText, out var b))
                return CalcResult.Fail("Друге число введено некоректно.");

            if (!InRange(a) || !InRange(b))
                return CalcResult.Fail($"Числа мають бути в діапазоні [{MinValueAllowed}; {MaxValueAllowed}].");

            if (operation == CalcOperation.Divide && Math.Abs(b) < 1e-12)
                return CalcResult.Fail("Ділення на нуль заборонено.");

           
            if (operation == CalcOperation.Power)
            {
                if (Math.Abs(a) < 1e-12 && b < 0)
                    return CalcResult.Fail("0 у від'ємному степені не визначено.");
            }

            try
            {
                var value = _realCalculator.Calculate(a, b, operation);

                if (double.IsNaN(value) || double.IsInfinity(value))
                    return CalcResult.Fail("Результат не є коректним числом (NaN/∞).");

                return CalcResult.Ok(value, "Обчислення виконано успішно.");
            }
            catch (Exception ex)
            {
                return CalcResult.Fail("Помилка обчислення: " + ex.Message);
            }
        }

        private static bool TryParseNumber(string text, out double value)
        {
            value = 0;

            if (string.IsNullOrWhiteSpace(text))
                return false;

           
            text = text.Trim().Replace(',', '.');

            return double.TryParse(
                text,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value);
        }

        private static bool InRange(double x) => x >= MinValueAllowed && x <= MaxValueAllowed;
    }
}
