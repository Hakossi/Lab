namespace Lab10.Proxy
{

    public interface ICalculatorService
    {
        CalcResult Calculate(string aText, string bText, CalcOperation operation);
    }
}
