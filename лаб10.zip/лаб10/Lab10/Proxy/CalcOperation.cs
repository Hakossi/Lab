namespace Lab10.Proxy
{
    public enum CalcOperation
    {
        Add,
        Subtract,
        Multiply,
        Divide,
        Power
    }
}
