namespace Lab10.Proxy
{
    public interface ICalculator
    {
        double Calculate(double a, double b, CalcOperation operation);
    }
}
