using System;

namespace Lab10.Proxy
{
    public sealed class RealCalculator : ICalculator
    {
        public double Calculate(double a, double b, CalcOperation operation)
        {
            switch (operation)
            {
                case CalcOperation.Add:
                    return a + b;

                case CalcOperation.Subtract:
                    return a - b;

                case CalcOperation.Multiply:
                    return a * b;

                case CalcOperation.Divide:
                    return a / b;

                case CalcOperation.Power:
                    return Math.Pow(a, b);

                default:
                    throw new ArgumentOutOfRangeException(nameof(operation), operation, "Невідома операція.");
            }
        }
    }
}
