using System;
using System.Globalization;
using System.Windows.Forms;
using Lab10.Proxy;

namespace Lab10
{
    public partial class MainForm : Form
    {
        private readonly ICalculatorService _calculator;

        public MainForm()
        {
            InitializeComponent();

            _calculator = new CalculatorProxy(new RealCalculator());

            cmbOperation.SelectedIndex = 0;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var operation = GetSelectedOperation();

            var result = _calculator.Calculate(txtA.Text, txtB.Text, operation);

            if (result.Success)
            {
                txtResult.Text = result.Value.ToString("G", CultureInfo.InvariantCulture);
            }
            else
            {
                txtResult.Text = string.Empty;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtA.Text = string.Empty;
            txtB.Text = string.Empty;
            txtResult.Text = string.Empty;
            txtA.Focus();
        }

        private CalcOperation GetSelectedOperation()
        {
            switch (cmbOperation.SelectedIndex)
            {
                case 0: return CalcOperation.Add;
                case 1: return CalcOperation.Subtract;
                case 2: return CalcOperation.Multiply;
                case 3: return CalcOperation.Divide;
                case 4: return CalcOperation.Power;
                default: return CalcOperation.Add;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
