namespace _6
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Очистити всі використовувані ресурси.
        /// </summary>
        /// <param name="disposing">true, якщо керовані ресурси слід видалити; інакше false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, створений конструктором форм Windows

        /// <summary>
        /// Обов'язковий метод для підтримки конструктора - не змінюйте
        /// вміст цього методу за допомогою редактора коду.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonSetToArray = new System.Windows.Forms.Button();
            this.buttonArrayToSet = new System.Windows.Forms.Button();
            this.buttonAddToSet = new System.Windows.Forms.Button();
            this.buttonAddToArray = new System.Windows.Forms.Button();
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.labelValueCaption = new System.Windows.Forms.Label();
            this.listBoxArray = new System.Windows.Forms.ListBox();
            this.listBoxSet = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(350, 146);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(85, 23);
            this.buttonClear.TabIndex = 6;
            this.buttonClear.Text = "Очистити";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonSetToArray
            // 
            this.buttonSetToArray.Location = new System.Drawing.Point(326, 117);
            this.buttonSetToArray.Name = "buttonSetToArray";
            this.buttonSetToArray.Size = new System.Drawing.Size(140, 23);
            this.buttonSetToArray.TabIndex = 5;
            this.buttonSetToArray.Text = "З множини до масиву";
            this.buttonSetToArray.UseVisualStyleBackColor = true;
            this.buttonSetToArray.Click += new System.EventHandler(this.buttonSetToArray_Click);
            // 
            // buttonArrayToSet
            // 
            this.buttonArrayToSet.Location = new System.Drawing.Point(326, 88);
            this.buttonArrayToSet.Name = "buttonArrayToSet";
            this.buttonArrayToSet.Size = new System.Drawing.Size(140, 23);
            this.buttonArrayToSet.TabIndex = 4;
            this.buttonArrayToSet.Text = "З масиву до множини\r\n";
            this.buttonArrayToSet.UseVisualStyleBackColor = true;
            this.buttonArrayToSet.Click += new System.EventHandler(this.buttonArrayToSet_Click);
            // 
            // buttonAddToSet
            // 
            this.buttonAddToSet.Location = new System.Drawing.Point(392, 59);
            this.buttonAddToSet.Name = "buttonAddToSet";
            this.buttonAddToSet.Size = new System.Drawing.Size(85, 23);
            this.buttonAddToSet.TabIndex = 3;
            this.buttonAddToSet.Text = "До множини";
            this.buttonAddToSet.UseVisualStyleBackColor = true;
            this.buttonAddToSet.Click += new System.EventHandler(this.buttonAddToSet_Click);
            // 
            // buttonAddToArray
            // 
            this.buttonAddToArray.Location = new System.Drawing.Point(304, 59);
            this.buttonAddToArray.Name = "buttonAddToArray";
            this.buttonAddToArray.Size = new System.Drawing.Size(82, 23);
            this.buttonAddToArray.TabIndex = 2;
            this.buttonAddToArray.Text = "До масиву";
            this.buttonAddToArray.UseVisualStyleBackColor = true;
            this.buttonAddToArray.Click += new System.EventHandler(this.buttonAddToArray_Click);
            // 
            // textBoxValue
            // 
            this.textBoxValue.Location = new System.Drawing.Point(371, 12);
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.Size = new System.Drawing.Size(80, 20);
            this.textBoxValue.TabIndex = 1;
            // 
            // labelValueCaption
            // 
            this.labelValueCaption.AutoSize = true;
            this.labelValueCaption.Location = new System.Drawing.Point(323, 15);
            this.labelValueCaption.Name = "labelValueCaption";
            this.labelValueCaption.Size = new System.Drawing.Size(42, 13);
            this.labelValueCaption.TabIndex = 0;
            this.labelValueCaption.Text = "Число:";
            // 
            // listBoxArray
            // 
            this.listBoxArray.FormattingEnabled = true;
            this.listBoxArray.Location = new System.Drawing.Point(21, 12);
            this.listBoxArray.Name = "listBoxArray";
            this.listBoxArray.Size = new System.Drawing.Size(278, 290);
            this.listBoxArray.TabIndex = 1;
            // 
            // listBoxSet
            // 
            this.listBoxSet.FormattingEnabled = true;
            this.listBoxSet.Location = new System.Drawing.Point(483, 12);
            this.listBoxSet.Name = "listBoxSet";
            this.listBoxSet.Size = new System.Drawing.Size(270, 303);
            this.listBoxSet.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 346);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.listBoxSet);
            this.Controls.Add(this.buttonSetToArray);
            this.Controls.Add(this.buttonArrayToSet);
            this.Controls.Add(this.listBoxArray);
            this.Controls.Add(this.buttonAddToSet);
            this.Controls.Add(this.buttonAddToArray);
            this.Controls.Add(this.textBoxValue);
            this.Controls.Add(this.labelValueCaption);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonAddToArray;
        private System.Windows.Forms.TextBox textBoxValue;
        private System.Windows.Forms.Label labelValueCaption;
        private System.Windows.Forms.Button buttonSetToArray;
        private System.Windows.Forms.Button buttonArrayToSet;
        private System.Windows.Forms.Button buttonAddToSet;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.ListBox listBoxArray;
        private System.Windows.Forms.ListBox listBoxSet;
    }
}
