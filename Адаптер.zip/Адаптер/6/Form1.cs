using System;
using System.Windows.Forms;

namespace _6
{
    public partial class Form1 : Form
    {
        private readonly DynamicIntArray _array = new DynamicIntArray();
        private readonly IntSet _set = new IntSet();

        public Form1()
        {
            InitializeComponent();
            UpdateViews();
        }

        private void buttonAddToArray_Click(object sender, EventArgs e)
        {
            if (!TryReadValue(out int value))
                return;

            _array.Add(value);
            UpdateViews();
        }

        private void buttonAddToSet_Click(object sender, EventArgs e)
        {
            if (!TryReadValue(out int value))
                return;

            _set.Add(value);
            UpdateViews();
        }

        private void buttonArrayToSet_Click(object sender, EventArgs e)
        {
            // Адаптер: клієнт очікує множину, а ми маємо масив
            IIntSet adapter = new ArrayToSetAdapter(_array);
            _set.Clear();
            foreach (var v in adapter.ToArray())
            {
                _set.Add(v);
            }
            UpdateViews();
        }

        private void buttonSetToArray_Click(object sender, EventArgs e)
        {
            // Адаптер: клієнт очікує масив, а ми маємо множину
            IIntArray adapter = new SetToArrayAdapter(_set);
            _array.Clear();
            foreach (var v in adapter.ToArray())
            {
                _array.Add(v);
            }
            UpdateViews();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            _array.Clear();
            _set.Clear();
            UpdateViews();
        }

        private bool TryReadValue(out int value)
        {
            if (!int.TryParse(textBoxValue.Text.Trim(), out value))
            {
                MessageBox.Show("Введіть коректне ціле число", "Помилка вводу", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void UpdateViews()
        {
            listBoxArray.Items.Clear();
            foreach (var v in _array.ToArray())
            {
                listBoxArray.Items.Add(v);
            }
            listBoxSet.Items.Clear();
            foreach (var v in _set.ToArray())
            {
                listBoxSet.Items.Add(v);
            }
        }

        private void listBoxSet_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
