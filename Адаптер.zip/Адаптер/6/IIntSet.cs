namespace _6
{
    public interface IIntSet
    {
        void Add(int value);
        bool Contains(int value);
        int Count { get; }
        int[] ToArray();
        void Clear();
    }
}
