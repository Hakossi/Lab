namespace _6
{
    public interface IIntArray
    {
        void Add(int value);
        int Length { get; }
        int this[int index] { get; }
        int[] ToArray();
        void Clear();
    }
}
