using System.Collections.Generic;

namespace _6
{
    public class DynamicIntArray : IIntArray
    {
        private readonly List<int> _items = new List<int>();

        public void Add(int value)
        {
            _items.Add(value);
        }

        public int Length => _items.Count;

        public int this[int index] => _items[index];

        public int[] ToArray()
        {
            return _items.ToArray();
        }

        public void Clear()
        {
            _items.Clear();
        }
    }
}
