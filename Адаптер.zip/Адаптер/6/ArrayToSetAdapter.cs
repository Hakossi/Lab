using System.Collections.Generic;

namespace _6
{

    public class ArrayToSetAdapter : IIntSet
    {
        private readonly IIntArray _array;

        public ArrayToSetAdapter(IIntArray array)
        {
            _array = array;
        }

        public void Add(int value)
        {
            for (int i = 0; i < _array.Length; i++)
            {
                if (_array[i] == value)
                {
                    return;
                }
            }
            _array.Add(value);
        }

        public bool Contains(int value)
        {
            for (int i = 0; i < _array.Length; i++)
            {
                if (_array[i] == value)
                {
                    return true;
                }
            }
            return false;
        }

        public int Count
        {
            get
            {
                return ToArray().Length;
            }
        }

        public int[] ToArray()
        {
            var unique = new HashSet<int>();
            for (int i = 0; i < _array.Length; i++)
            {
                unique.Add(_array[i]);
            }

            int[] result = new int[unique.Count];
            unique.CopyTo(result);
            return result;
        }

        public void Clear()
        {
            _array.Clear();
        }
    }
}
