using System;

namespace _6
{

    public class SetToArrayAdapter : IIntArray
    {
        private readonly IIntSet _set;

        public SetToArrayAdapter(IIntSet set)
        {
            _set = set;
        }

        public void Add(int value)
        {
           
            _set.Add(value);
        }

        public int Length => _set.Count;

        public int this[int index]
        {
            get
            {
                int[] data = _set.ToArray();
                if (index < 0 || index >= data.Length)
                {
                    throw new IndexOutOfRangeException();
                }
                return data[index];
            }
        }

        public int[] ToArray()
        {
            return _set.ToArray();
        }

        public void Clear()
        {
            _set.Clear();
        }
    }
}
