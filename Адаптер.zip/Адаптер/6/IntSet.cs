using System.Collections.Generic;

namespace _6
{
    public class IntSet : IIntSet
    {
        private readonly HashSet<int> _items = new HashSet<int>();

        public void Add(int value)
        {
            _items.Add(value);
        }

        public bool Contains(int value)
        {
            return _items.Contains(value);
        }

        public int Count => _items.Count;

        public int[] ToArray()
        {
            int[] result = new int[_items.Count];
            _items.CopyTo(result);
            return result;
        }

        public void Clear()
        {
            _items.Clear();
        }
    }
}
