using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Lab7
{
    public partial class MainForm : Form
    {
        private readonly BirdFactory _factory = new BirdFactory();
        private readonly List<Bird> _birds = new List<Bird>();
        private readonly Random _rnd = new Random();

        public MainForm()
        {
            InitializeComponent();

        
            DoubleBuffered = true;

            cbBirdType.SelectedIndex = 0;
            UpdateStats();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int count = (int)numCount.Value;
            string selected = cbBirdType.SelectedItem?.ToString() ?? "Sparrow";

            for (int i = 0; i < count; i++)
            {
                string typeName = selected.Equals("Random", StringComparison.OrdinalIgnoreCase)
                    ? PickRandomType()
                    : selected;

                var type = _factory.Get(typeName);

                
                var bounds = GetSkyBounds();
                float x = (float)(_rnd.NextDouble() * (bounds.Width - 40) + bounds.Left + 20);
                float y = (float)(_rnd.NextDouble() * (bounds.Height - 40) + bounds.Top + 20);

                
                float vx = (float)(_rnd.NextDouble() * 160 + 40) * (_rnd.Next(0, 2) == 0 ? -1 : 1);
                float vy = (float)(_rnd.NextDouble() * 80 - 40);

                _birds.Add(new Bird(type, x, y, vx, vy));
            }

            UpdateStats();
            Invalidate();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            _birds.Clear();
            UpdateStats();
            Invalidate();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          
            float dt = timer1.Interval / 1000f;

            var bounds = GetSkyBounds();
            float minX = bounds.Left + 10;
            float maxX = bounds.Right - 10;
            float minY = bounds.Top + 10;
            float maxY = bounds.Bottom - 10;

            for (int i = 0; i < _birds.Count; i++)
                _birds[i].Update(dt, minX, minY, maxX, maxY);

            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            
            using (var brush = new LinearGradientBrush(ClientRectangle, Color.FromArgb(235, 245, 255), Color.FromArgb(185, 220, 255), 90f))
            {
                g.FillRectangle(brush, ClientRectangle);
            }

           
            DrawCloud(g, 260, 130, 80);
            DrawCloud(g, 600, 160, 90);
            DrawCloud(g, 420, 210, 70);

            for (int i = 0; i < _birds.Count; i++)
            {
                var b = _birds[i];
                b.Type.Draw(g, b.X, b.Y, b.FlapPhase);
            }

          
            using (var pen = new Pen(Color.FromArgb(130, 130, 130), 1f))
            {
                var y = GetSkyBounds().Top - 6;
                g.DrawLine(pen, 8, y, ClientSize.Width - 8, y);
            }
        }

        private void DrawCloud(Graphics g, float x, float y, float r)
        {
            using (var b = new SolidBrush(Color.FromArgb(210, 255, 255, 255)))
            {
                g.FillEllipse(b, x - r, y - r * 0.45f, r * 1.25f, r * 0.9f);
                g.FillEllipse(b, x - r * 0.2f, y - r * 0.6f, r * 1.4f, r * 1.0f);
                g.FillEllipse(b, x + r * 0.55f, y - r * 0.45f, r * 1.1f, r * 0.85f);
            }
        }

        private Rectangle GetSkyBounds()
        {
            
            int top = 90;
            return new Rectangle(0, top, ClientSize.Width, ClientSize.Height - top);
        }

        private void UpdateStats()
        {
            lblStats.Text = $"�����: {_birds.Count} | ���������� ���� (Flyweights): {_factory.UniqueTypesCount}";
        }

        private string PickRandomType()
        {
           
            string[] types = { "Sparrow", "Seagull", "Crow", "Swallow", "Eagle" };
            return types[_rnd.Next(types.Length)];
        }

        private void lblStats_Click(object sender, EventArgs e)
        {

        }
    }
}
