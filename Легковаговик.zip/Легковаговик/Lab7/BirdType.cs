using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace Lab7
{

    public sealed class BirdType
    {
        public string Name { get; }
        public Color Color { get; }
        public float Size { get; }         
        public float WingSpan { get; }     

        public BirdType(string name, Color color, float size, float wingSpan)
        {
            Name = name;
            Color = color;
            Size = size;
            WingSpan = wingSpan;
        }

        public void Draw(Graphics g, float x, float y, float flapPhase)
        {
       
            float amp = 6f * Size + (float)Math.Sin(flapPhase) * (4f * Size);
            float w = WingSpan * Size;
            float h = 10f * Size;

            using (var pen = new Pen(Color, 2f))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;

              
                var p1 = new PointF(x - w, y);
                var p2 = new PointF(x - w / 2f, y - amp);
                var p3 = new PointF(x, y);


                var p4 = new PointF(x, y);
                var p5 = new PointF(x + w / 2f, y - amp);
                var p6 = new PointF(x + w, y);

                g.DrawCurve(pen, new[] { p1, p2, p3 }, 0.4f);
                g.DrawCurve(pen, new[] { p4, p5, p6 }, 0.4f);


                using (var b = new SolidBrush(Color))
                {
                    g.FillEllipse(b, x - 1.5f, y - 1.5f, 3f, 3f);
                }
            }
        }
    }
}
