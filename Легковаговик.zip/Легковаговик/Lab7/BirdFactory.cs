using System;
using System.Collections.Generic;
using System.Drawing;

namespace Lab7
{

    public sealed class BirdFactory
    {
        private readonly Dictionary<string, BirdType> _cache = new Dictionary<string, BirdType>(StringComparer.OrdinalIgnoreCase);

        public BirdType Get(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                name = "Sparrow";

            if (_cache.TryGetValue(name, out var type))
                return type;

           
            type = CreateType(name);
            _cache[name] = type;
            return type;
        }

        public int UniqueTypesCount => _cache.Count;

        private static BirdType CreateType(string name)
        {
            
            switch (name.Trim().ToLowerInvariant())
            {
                case "seagull":
                case "чайка":
                    return new BirdType("Seagull", Color.SlateGray, size: 1.25f, wingSpan: 18f);

                case "crow":
                case "ворона":
                    return new BirdType("Crow", Color.FromArgb(35, 35, 35), size: 1.15f, wingSpan: 16f);

                case "swallow":
                case "ластівка":
                case "ласточка":
                    return new BirdType("Swallow", Color.MidnightBlue, size: 1.05f, wingSpan: 15f);

                case "eagle":
                case "орел":
                    return new BirdType("Eagle", Color.SaddleBrown, size: 1.45f, wingSpan: 22f);

                default:
                    return new BirdType("Sparrow", Color.DimGray, size: 1.0f, wingSpan: 14f);
            }
        }
    }
}
