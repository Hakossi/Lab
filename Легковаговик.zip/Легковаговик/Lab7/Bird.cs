using System;

namespace Lab7
{

    public sealed class Bird
    {
        public BirdType Type { get; }

        public float X { get; private set; }
        public float Y { get; private set; }
        public float Vx { get; private set; }
        public float Vy { get; private set; }

        private float _flapPhase;

        public Bird(BirdType type, float x, float y, float vx, float vy)
        {
            Type = type ?? throw new ArgumentNullException(nameof(type));
            X = x;
            Y = y;
            Vx = vx;
            Vy = vy;
            _flapPhase = 0f;
        }

        public void Update(float dt, float minX, float minY, float maxX, float maxY)
        {
            X += Vx * dt;
            Y += Vy * dt;

           
            if (X < minX) { X = minX; Vx = -Vx; }
            if (X > maxX) { X = maxX; Vx = -Vx; }
            if (Y < minY) { Y = minY; Vy = -Vy; }
            if (Y > maxY) { Y = maxY; Vy = -Vy; }

         
            _flapPhase += 8f * dt;
        }

        public float FlapPhase => _flapPhase;
    }
}
