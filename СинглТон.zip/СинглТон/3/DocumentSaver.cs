using System;
using System.Collections.Generic;

namespace _3
{


    public sealed class DocumentSaver
    {
        private static readonly Lazy<DocumentSaver> _instance =
            new Lazy<DocumentSaver>(() => new DocumentSaver());

        public static DocumentSaver Instance => _instance.Value;

        private readonly Dictionary<string, string> _documents =
            new Dictionary<string, string>();

        private DocumentSaver()
        {
        }

        public void SaveDocument(string name, string content)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Назва документа не може бути порожньою.");

            _documents[name] = content ?? string.Empty;
            Logger.Instance.Log($"DocumentSaver: збережено документ '{name}'");
        }

        public IReadOnlyDictionary<string, string> GetAllDocuments()
        {
            return _documents;
        }

        public bool TryGetDocument(string name, out string content)
        {
            return _documents.TryGetValue(name, out content);
        }
    }
}
