using System;
using System.Collections.Generic;

namespace _3
{

    public sealed class DbManager
    {
        private static readonly Lazy<DbManager> _instance =
            new Lazy<DbManager>(() => new DbManager());

        public static DbManager Instance => _instance.Value;

        private readonly List<string> _records = new List<string>();

        public string ConnectionString { get; private set; }
        public bool IsConnected { get; private set; }

        private DbManager()
        {
           
            ConnectionString = string.Empty;
            IsConnected = false;
        }

        public void Connect(string connectionString)
        {
            ConnectionString = connectionString;
            IsConnected = true;
            Logger.Instance.Log($"DB: підключення до '{connectionString}'");
        }

        public void Disconnect()
        {
            IsConnected = false;
            Logger.Instance.Log("DB: відключення");
        }

        public void AddRecord(string record)
        {
            if (!IsConnected)
                throw new InvalidOperationException("База даних не підключена.");

            _records.Add(record);
            Logger.Instance.Log($"DB: додано запис '{record}'");
        }

        public IReadOnlyList<string> GetRecords()
        {
            return _records.AsReadOnly();
        }
    }
}
