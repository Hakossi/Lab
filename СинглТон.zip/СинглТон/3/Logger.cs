using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace _3
{

    public sealed class Logger
    {
        private static readonly Lazy<Logger> _instance =
            new Lazy<Logger>(() => new Logger());

        public static Logger Instance => _instance.Value;

        private readonly object _sync = new object();
        private readonly List<string> _entries = new List<string>();
        private readonly string _logFilePath;

        private Logger()
        {
            _logFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app.log");
            Log("Logger запущений");
        }

        public void Log(string message)
        {
            var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}";
            lock (_sync)
            {
                _entries.Add(line);
                try
                {
                    File.AppendAllText(_logFilePath, line + Environment.NewLine, Encoding.UTF8);
                }
                catch
                {
                    
                }
            }
        }

        public IReadOnlyList<string> GetEntries()
        {
            lock (_sync)
            {
                return _entries.ToArray();
            }
        }
    }
}
