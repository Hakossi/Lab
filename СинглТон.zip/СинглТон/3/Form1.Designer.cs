namespace _3
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Чистимо ресурси.
        /// </summary>
        /// <param name="disposing">true, якщо керовані ресурси слід видалити; інакше false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, створений конструктором форм Windows

        /// <summary>
        /// Мінімалістична форма без GroupBox/Panel.
        /// Просто розкидав контролли як студент на 4 курсі :)
        /// </summary>
        private void InitializeComponent()
        {
            this.labelConnectionString = new System.Windows.Forms.Label();
            this.textBoxConnectionString = new System.Windows.Forms.TextBox();
            this.buttonConnectDb = new System.Windows.Forms.Button();
            this.buttonDisconnectDb = new System.Windows.Forms.Button();
            this.labelDbStatus = new System.Windows.Forms.Label();
            this.labelRecordText = new System.Windows.Forms.Label();
            this.textBoxRecordText = new System.Windows.Forms.TextBox();
            this.buttonAddRecord = new System.Windows.Forms.Button();
            this.labelDbRecords = new System.Windows.Forms.Label();
            this.listBoxDbRecords = new System.Windows.Forms.ListBox();
            this.labelDocName = new System.Windows.Forms.Label();
            this.textBoxDocName = new System.Windows.Forms.TextBox();
            this.labelDocContent = new System.Windows.Forms.Label();
            this.textBoxDocContent = new System.Windows.Forms.TextBox();
            this.buttonSaveDocument = new System.Windows.Forms.Button();
            this.labelDocuments = new System.Windows.Forms.Label();
            this.listBoxDocuments = new System.Windows.Forms.ListBox();
            this.labelDocDetails = new System.Windows.Forms.Label();
            this.textBoxDocDetails = new System.Windows.Forms.TextBox();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.buttonRefreshLog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelConnectionString
            // 
            this.labelConnectionString.AutoSize = true;
            this.labelConnectionString.Location = new System.Drawing.Point(12, 30);
            this.labelConnectionString.Name = "labelConnectionString";
            this.labelConnectionString.Size = new System.Drawing.Size(107, 13);
            this.labelConnectionString.TabIndex = 1;
            this.labelConnectionString.Text = "Рядок підключення:";
            // 
            // textBoxConnectionString
            // 
            this.textBoxConnectionString.Location = new System.Drawing.Point(119, 27);
            this.textBoxConnectionString.Name = "textBoxConnectionString";
            this.textBoxConnectionString.Size = new System.Drawing.Size(220, 20);
            this.textBoxConnectionString.TabIndex = 2;
            this.textBoxConnectionString.Text = "Server=localhost;Database=Demo;";
            // 
            // buttonConnectDb
            // 
            this.buttonConnectDb.Location = new System.Drawing.Point(355, 25);
            this.buttonConnectDb.Name = "buttonConnectDb";
            this.buttonConnectDb.Size = new System.Drawing.Size(90, 23);
            this.buttonConnectDb.TabIndex = 3;
            this.buttonConnectDb.Text = "Підключитись";
            this.buttonConnectDb.UseVisualStyleBackColor = true;
            this.buttonConnectDb.Click += new System.EventHandler(this.buttonConnectDb_Click);
            // 
            // buttonDisconnectDb
            // 
            this.buttonDisconnectDb.Location = new System.Drawing.Point(451, 25);
            this.buttonDisconnectDb.Name = "buttonDisconnectDb";
            this.buttonDisconnectDb.Size = new System.Drawing.Size(90, 23);
            this.buttonDisconnectDb.TabIndex = 4;
            this.buttonDisconnectDb.Text = "Відключитись";
            this.buttonDisconnectDb.UseVisualStyleBackColor = true;
            this.buttonDisconnectDb.Click += new System.EventHandler(this.buttonDisconnectDb_Click);
            // 
            // labelDbStatus
            // 
            this.labelDbStatus.AutoSize = true;
            this.labelDbStatus.Location = new System.Drawing.Point(12, 55);
            this.labelDbStatus.Name = "labelDbStatus";
            this.labelDbStatus.Size = new System.Drawing.Size(138, 13);
            this.labelDbStatus.TabIndex = 5;
            this.labelDbStatus.Text = "Статус БД: не підключено";
            // 
            // labelRecordText
            // 
            this.labelRecordText.AutoSize = true;
            this.labelRecordText.Location = new System.Drawing.Point(12, 80);
            this.labelRecordText.Name = "labelRecordText";
            this.labelRecordText.Size = new System.Drawing.Size(75, 13);
            this.labelRecordText.TabIndex = 6;
            this.labelRecordText.Text = "Новий запис:";
            // 
            // textBoxRecordText
            // 
            this.textBoxRecordText.Location = new System.Drawing.Point(92, 77);
            this.textBoxRecordText.Name = "textBoxRecordText";
            this.textBoxRecordText.Size = new System.Drawing.Size(267, 20);
            this.textBoxRecordText.TabIndex = 7;
            // 
            // buttonAddRecord
            // 
            this.buttonAddRecord.Location = new System.Drawing.Point(372, 75);
            this.buttonAddRecord.Name = "buttonAddRecord";
            this.buttonAddRecord.Size = new System.Drawing.Size(100, 23);
            this.buttonAddRecord.TabIndex = 8;
            this.buttonAddRecord.Text = "Додати в БД";
            this.buttonAddRecord.UseVisualStyleBackColor = true;
            this.buttonAddRecord.Click += new System.EventHandler(this.buttonAddRecord_Click);
            // 
            // labelDbRecords
            // 
            this.labelDbRecords.AutoSize = true;
            this.labelDbRecords.Location = new System.Drawing.Point(12, 110);
            this.labelDbRecords.Name = "labelDbRecords";
            this.labelDbRecords.Size = new System.Drawing.Size(75, 13);
            this.labelDbRecords.TabIndex = 9;
            this.labelDbRecords.Text = "Записи в БД:";
            // 
            // listBoxDbRecords
            // 
            this.listBoxDbRecords.FormattingEnabled = true;
            this.listBoxDbRecords.Location = new System.Drawing.Point(15, 130);
            this.listBoxDbRecords.Name = "listBoxDbRecords";
            this.listBoxDbRecords.Size = new System.Drawing.Size(300, 108);
            this.listBoxDbRecords.TabIndex = 10;
            // 
            // labelDocName
            // 
            this.labelDocName.AutoSize = true;
            this.labelDocName.Location = new System.Drawing.Point(12, 275);
            this.labelDocName.Name = "labelDocName";
            this.labelDocName.Size = new System.Drawing.Size(99, 13);
            this.labelDocName.TabIndex = 12;
            this.labelDocName.Text = "Назва документа:";
            // 
            // textBoxDocName
            // 
            this.textBoxDocName.Location = new System.Drawing.Point(114, 272);
            this.textBoxDocName.Name = "textBoxDocName";
            this.textBoxDocName.Size = new System.Drawing.Size(201, 20);
            this.textBoxDocName.TabIndex = 13;
            // 
            // labelDocContent
            // 
            this.labelDocContent.AutoSize = true;
            this.labelDocContent.Location = new System.Drawing.Point(12, 300);
            this.labelDocContent.Name = "labelDocContent";
            this.labelDocContent.Size = new System.Drawing.Size(75, 13);
            this.labelDocContent.TabIndex = 14;
            this.labelDocContent.Text = "Текст док-та:";
            // 
            // textBoxDocContent
            // 
            this.textBoxDocContent.Location = new System.Drawing.Point(15, 320);
            this.textBoxDocContent.Multiline = true;
            this.textBoxDocContent.Name = "textBoxDocContent";
            this.textBoxDocContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDocContent.Size = new System.Drawing.Size(300, 80);
            this.textBoxDocContent.TabIndex = 15;
            // 
            // buttonSaveDocument
            // 
            this.buttonSaveDocument.Location = new System.Drawing.Point(15, 410);
            this.buttonSaveDocument.Name = "buttonSaveDocument";
            this.buttonSaveDocument.Size = new System.Drawing.Size(140, 23);
            this.buttonSaveDocument.TabIndex = 16;
            this.buttonSaveDocument.Text = "Зберегти документ";
            this.buttonSaveDocument.UseVisualStyleBackColor = true;
            this.buttonSaveDocument.Click += new System.EventHandler(this.buttonSaveDocument_Click);
            // 
            // labelDocuments
            // 
            this.labelDocuments.AutoSize = true;
            this.labelDocuments.Location = new System.Drawing.Point(330, 250);
            this.labelDocuments.Name = "labelDocuments";
            this.labelDocuments.Size = new System.Drawing.Size(67, 13);
            this.labelDocuments.TabIndex = 17;
            this.labelDocuments.Text = "Документи:";
            // 
            // listBoxDocuments
            // 
            this.listBoxDocuments.FormattingEnabled = true;
            this.listBoxDocuments.Location = new System.Drawing.Point(333, 270);
            this.listBoxDocuments.Name = "listBoxDocuments";
            this.listBoxDocuments.Size = new System.Drawing.Size(208, 95);
            this.listBoxDocuments.TabIndex = 18;
            this.listBoxDocuments.SelectedIndexChanged += new System.EventHandler(this.listBoxDocuments_SelectedIndexChanged);
            // 
            // labelDocDetails
            // 
            this.labelDocDetails.AutoSize = true;
            this.labelDocDetails.Location = new System.Drawing.Point(330, 370);
            this.labelDocDetails.Name = "labelDocDetails";
            this.labelDocDetails.Size = new System.Drawing.Size(129, 13);
            this.labelDocDetails.TabIndex = 19;
            this.labelDocDetails.Text = "Вміст вибраного док-та:";
            // 
            // textBoxDocDetails
            // 
            this.textBoxDocDetails.Location = new System.Drawing.Point(333, 390);
            this.textBoxDocDetails.Multiline = true;
            this.textBoxDocDetails.Name = "textBoxDocDetails";
            this.textBoxDocDetails.ReadOnly = true;
            this.textBoxDocDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDocDetails.Size = new System.Drawing.Size(208, 80);
            this.textBoxDocDetails.TabIndex = 20;
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(573, 30);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.ReadOnly = true;
            this.textBoxLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxLog.Size = new System.Drawing.Size(260, 410);
            this.textBoxLog.TabIndex = 22;
            // 
            // buttonRefreshLog
            // 
            this.buttonRefreshLog.Location = new System.Drawing.Point(573, 450);
            this.buttonRefreshLog.Name = "buttonRefreshLog";
            this.buttonRefreshLog.Size = new System.Drawing.Size(120, 23);
            this.buttonRefreshLog.TabIndex = 23;
            this.buttonRefreshLog.Text = "Оновити лог";
            this.buttonRefreshLog.UseVisualStyleBackColor = true;
            this.buttonRefreshLog.Click += new System.EventHandler(this.buttonRefreshLog_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 485);
            this.Controls.Add(this.buttonRefreshLog);
            this.Controls.Add(this.textBoxLog);
            this.Controls.Add(this.textBoxDocDetails);
            this.Controls.Add(this.labelDocDetails);
            this.Controls.Add(this.listBoxDocuments);
            this.Controls.Add(this.labelDocuments);
            this.Controls.Add(this.buttonSaveDocument);
            this.Controls.Add(this.textBoxDocContent);
            this.Controls.Add(this.labelDocContent);
            this.Controls.Add(this.textBoxDocName);
            this.Controls.Add(this.labelDocName);
            this.Controls.Add(this.listBoxDbRecords);
            this.Controls.Add(this.labelDbRecords);
            this.Controls.Add(this.buttonAddRecord);
            this.Controls.Add(this.textBoxRecordText);
            this.Controls.Add(this.labelRecordText);
            this.Controls.Add(this.labelDbStatus);
            this.Controls.Add(this.buttonDisconnectDb);
            this.Controls.Add(this.buttonConnectDb);
            this.Controls.Add(this.textBoxConnectionString);
            this.Controls.Add(this.labelConnectionString);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelConnectionString;
        private System.Windows.Forms.TextBox textBoxConnectionString;
        private System.Windows.Forms.Button buttonConnectDb;
        private System.Windows.Forms.Button buttonDisconnectDb;
        private System.Windows.Forms.Label labelDbStatus;
        private System.Windows.Forms.Label labelRecordText;
        private System.Windows.Forms.TextBox textBoxRecordText;
        private System.Windows.Forms.Button buttonAddRecord;
        private System.Windows.Forms.Label labelDbRecords;
        private System.Windows.Forms.ListBox listBoxDbRecords;
        private System.Windows.Forms.Label labelDocName;
        private System.Windows.Forms.TextBox textBoxDocName;
        private System.Windows.Forms.Label labelDocContent;
        private System.Windows.Forms.TextBox textBoxDocContent;
        private System.Windows.Forms.Button buttonSaveDocument;
        private System.Windows.Forms.Label labelDocuments;
        private System.Windows.Forms.ListBox listBoxDocuments;
        private System.Windows.Forms.Label labelDocDetails;
        private System.Windows.Forms.TextBox textBoxDocDetails;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Button buttonRefreshLog;
    }
}
