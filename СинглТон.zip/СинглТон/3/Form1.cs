using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3
{
    public partial class Form1 : Form
    {
        // Як студент 4 курсу, показую тут три різні Singleton:
        // DbManager, DocumentSaver і Logger.

        public Form1()
        {
            InitializeComponent();
            Logger.Instance.Log("Програма запущена");
            UpdateDbStatus();
            RefreshLogView();
        }

        // --- Робота з "DB Manager" ---

        private void buttonConnectDb_Click(object sender, EventArgs e)
        {
            var conn = textBoxConnectionString.Text.Trim();
            if (string.IsNullOrEmpty(conn))
            {
                MessageBox.Show("Введіть рядок підключення.", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DbManager.Instance.Connect(conn);
            UpdateDbStatus();
            RefreshLogView();
        }

        private void buttonDisconnectDb_Click(object sender, EventArgs e)
        {
            DbManager.Instance.Disconnect();
            UpdateDbStatus();
            RefreshLogView();
        }

        private void buttonAddRecord_Click(object sender, EventArgs e)
        {
            var text = textBoxRecordText.Text.Trim();
            if (string.IsNullOrEmpty(text))
            {
                MessageBox.Show("Введіть текст запису.", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DbManager.Instance.AddRecord(text);
                textBoxRecordText.Clear();
                ReloadDbRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "DB помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            RefreshLogView();
        }

        private void ReloadDbRecords()
        {
            listBoxDbRecords.Items.Clear();
            foreach (var r in DbManager.Instance.GetRecords())
            {
                listBoxDbRecords.Items.Add(r);
            }
        }

        private void UpdateDbStatus()
        {
            if (DbManager.Instance.IsConnected)
            {
                labelDbStatus.Text = "Статус БД: підключено";
            }
            else
            {
                labelDbStatus.Text = "Статус БД: не підключено";
            }
        }

        // --- Робота з DocumentSaver ---

        private void buttonSaveDocument_Click(object sender, EventArgs e)
        {
            var name = textBoxDocName.Text.Trim();
            var content = textBoxDocContent.Text;

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введіть назву документа.", "Помилка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DocumentSaver.Instance.SaveDocument(name, content);
                ReloadDocuments();
                textBoxDocName.Clear();
                textBoxDocContent.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Помилка DocumentSaver",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            RefreshLogView();
        }

        private void ReloadDocuments()
        {
            listBoxDocuments.Items.Clear();
            foreach (var kv in DocumentSaver.Instance.GetAllDocuments())
            {
                listBoxDocuments.Items.Add(kv.Key);
            }
        }

        private void listBoxDocuments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxDocuments.SelectedItem is string name)
            {
                if (DocumentSaver.Instance.TryGetDocument(name, out var content))
                {
                    textBoxDocDetails.Text = content;
                }
                else
                {
                    textBoxDocDetails.Text = string.Empty;
                }
            }
        }

        // --- Перегляд логів ---

        private void RefreshLogView()
        {
            textBoxLog.Lines = Logger.Instance
                .GetEntries()
                .ToArray();
        }

        private void buttonRefreshLog_Click(object sender, EventArgs e)
        {
            RefreshLogView();
        }
    }
}
