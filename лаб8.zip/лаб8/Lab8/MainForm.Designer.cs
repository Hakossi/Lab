namespace Lab8
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.ComboBox cbBaseCake;
        private System.Windows.Forms.Label lblDecor;
        private System.Windows.Forms.CheckedListBox clbDecorators;
        private System.Windows.Forms.Button btnBuild;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.TextBox tbDescription;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.TextBox tbCost;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.cbBaseCake = new System.Windows.Forms.ComboBox();
            this.lblDecor = new System.Windows.Forms.Label();
            this.clbDecorators = new System.Windows.Forms.CheckedListBox();
            this.btnBuild = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblDesc = new System.Windows.Forms.Label();
            this.tbDescription = new System.Windows.Forms.TextBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.tbCost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(0, 21);
            this.lblTitle.TabIndex = 0;
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Location = new System.Drawing.Point(13, 45);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(78, 13);
            this.lblBase.TabIndex = 1;
            this.lblBase.Text = "Базовий торт:";
            // 
            // cbBaseCake
            // 
            this.cbBaseCake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaseCake.FormattingEnabled = true;
            this.cbBaseCake.Location = new System.Drawing.Point(16, 62);
            this.cbBaseCake.Name = "cbBaseCake";
            this.cbBaseCake.Size = new System.Drawing.Size(238, 21);
            this.cbBaseCake.TabIndex = 2;
            // 
            // lblDecor
            // 
            this.lblDecor.AutoSize = true;
            this.lblDecor.Location = new System.Drawing.Point(13, 95);
            this.lblDecor.Name = "lblDecor";
            this.lblDecor.Size = new System.Drawing.Size(72, 13);
            this.lblDecor.TabIndex = 3;
            this.lblDecor.Text = "Декоратори:";
            // 
            // clbDecorators
            // 
            this.clbDecorators.CheckOnClick = true;
            this.clbDecorators.FormattingEnabled = true;
            this.clbDecorators.Location = new System.Drawing.Point(16, 112);
            this.clbDecorators.Name = "clbDecorators";
            this.clbDecorators.Size = new System.Drawing.Size(238, 94);
            this.clbDecorators.TabIndex = 4;
            // 
            // btnBuild
            // 
            this.btnBuild.Location = new System.Drawing.Point(16, 217);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(114, 28);
            this.btnBuild.TabIndex = 5;
            this.btnBuild.Text = "Зібрати торт";
            this.btnBuild.UseVisualStyleBackColor = true;
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(140, 217);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(114, 28);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Скидання";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Location = new System.Drawing.Point(13, 259);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(36, 13);
            this.lblDesc.TabIndex = 7;
            this.lblDesc.Text = "Опис:";
            // 
            // tbDescription
            // 
            this.tbDescription.Location = new System.Drawing.Point(16, 276);
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.ReadOnly = true;
            this.tbDescription.Size = new System.Drawing.Size(238, 54);
            this.tbDescription.TabIndex = 8;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(13, 343);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(32, 13);
            this.lblCost.TabIndex = 9;
            this.lblCost.Text = "Ціна:";
            // 
            // tbCost
            // 
            this.tbCost.Location = new System.Drawing.Point(16, 360);
            this.tbCost.Name = "tbCost";
            this.tbCost.ReadOnly = true;
            this.tbCost.Size = new System.Drawing.Size(238, 20);
            this.tbCost.TabIndex = 10;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(272, 397);
            this.Controls.Add(this.tbCost);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.tbDescription);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnBuild);
            this.Controls.Add(this.clbDecorators);
            this.Controls.Add(this.lblDecor);
            this.Controls.Add(this.cbBaseCake);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
