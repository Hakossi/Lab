using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Lab8
{
    public partial class MainForm : Form
    {
        private readonly Dictionary<string, Func<ICake>> _baseCakeMap;

        public MainForm()
        {
            InitializeComponent();

            _baseCakeMap = new Dictionary<string, Func<ICake>>(StringComparer.OrdinalIgnoreCase)
            {
                { "Ванільный", () => new VanillaCake() },
                { "Шоколадний", () => new ChocolateCake() },
                { "Чізкейк", () => new Cheesecake() }
            };

            cbBaseCake.Items.AddRange(new object[] { "Ванільный", "Шоколадний", "Чізкейк" });
            cbBaseCake.SelectedIndex = 0;

            clbDecorators.Items.AddRange(new object[]
            {
                "Крем",
                "Шоколадна глазурь",
                "Ягоди",
                "Горіхи",
                "Свічки"
            });

            UpdateResult(new VanillaCake());
        }

        private void btnBuild_Click(object sender, EventArgs e)
        {
            var baseName = cbBaseCake.SelectedItem?.ToString() ?? "Ванільный";
            ICake cake = _baseCakeMap.ContainsKey(baseName) ? _baseCakeMap[baseName]() : (ICake)new VanillaCake();

            foreach (var item in clbDecorators.CheckedItems)
            {
                var deco = item.ToString();
                cake = ApplyDecorator(cake, deco);
            }

            UpdateResult(cake);
        }

        private static ICake ApplyDecorator(ICake cake, string decoratorName)
        {
            switch (decoratorName)
            {
                case "Крем":
                    return new CreamDecorator(cake);
                case "Шоколадна глазурь":
                    return new ChocolateGlazeDecorator(cake);
                case "Ягоди":
                    return new BerriesDecorator(cake);
                case "Горіхи":
                    return new NutsDecorator(cake);
                case "Свічки":
                    return new CandlesDecorator(cake);
                default:
                    return cake;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            cbBaseCake.SelectedIndex = 0;
            for (int i = 0; i < clbDecorators.Items.Count; i++)
                clbDecorators.SetItemChecked(i, false);

            UpdateResult(new VanillaCake());
        }

        private void UpdateResult(ICake cake)
        {
            tbDescription.Text = cake.GetDescription();
            tbCost.Text = cake.GetCost().ToString("0.00") + " грн";
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
