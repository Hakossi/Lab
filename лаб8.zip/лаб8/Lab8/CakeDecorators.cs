namespace Lab8
{

    public abstract class CakeDecorator : Cake
    {
        protected readonly ICake Inner;

        protected CakeDecorator(ICake inner)
        {
            Inner = inner;
        }
    }

    public sealed class CreamDecorator : CakeDecorator
    {
        public CreamDecorator(ICake inner) : base(inner) { }
        public override string GetDescription() => Inner.GetDescription() + " + крем";
        public override decimal GetCost() => Inner.GetCost() + 35m;
    }

    public sealed class ChocolateGlazeDecorator : CakeDecorator
    {
        public ChocolateGlazeDecorator(ICake inner) : base(inner) { }
        public override string GetDescription() => Inner.GetDescription() + " + шоколадна глазурь";
        public override decimal GetCost() => Inner.GetCost() + 45m;
    }

    public sealed class BerriesDecorator : CakeDecorator
    {
        public BerriesDecorator(ICake inner) : base(inner) { }
        public override string GetDescription() => Inner.GetDescription() + " + ягоди";
        public override decimal GetCost() => Inner.GetCost() + 55m;
    }

    public sealed class NutsDecorator : CakeDecorator
    {
        public NutsDecorator(ICake inner) : base(inner) { }
        public override string GetDescription() => Inner.GetDescription() + " + горіхи";
        public override decimal GetCost() => Inner.GetCost() + 40m;
    }

    public sealed class CandlesDecorator : CakeDecorator
    {
        public CandlesDecorator(ICake inner) : base(inner) { }
        public override string GetDescription() => Inner.GetDescription() + " + свічки";
        public override decimal GetCost() => Inner.GetCost() + 20m;
    }
}
