namespace Lab8
{
    public interface ICake
    {
        string GetDescription();
        decimal GetCost();
    }

    public abstract class Cake : ICake
    {
        public abstract string GetDescription();
        public abstract decimal GetCost();
    }

    public sealed class VanillaCake : Cake
    {
        public override string GetDescription() => "Ванільный торт";
        public override decimal GetCost() => 220m;
    }

    public sealed class ChocolateCake : Cake
    {
        public override string GetDescription() => "Шоколадний торт";
        public override decimal GetCost() => 260m;
    }

    public sealed class Cheesecake : Cake
    {
        public override string GetDescription() => "Чізкейк";
        public override decimal GetCost() => 300m;
    }
}
