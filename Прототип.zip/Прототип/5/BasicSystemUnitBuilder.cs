namespace _5
{
  
    public class BasicSystemUnitBuilder : ISystemUnitBuilder
    {
        private SystemUnit _systemUnit;

        public BasicSystemUnitBuilder()
        {
            Reset();
        }

        public void Reset()
        {
            _systemUnit = new SystemUnit();
        }

        public void SetName(string name)
        {
            _systemUnit.Name = name;
        }

        public void SetCpu(string cpu)
        {
            _systemUnit.Cpu = cpu;
        }

        public void SetGpu(string gpu)
        {
            _systemUnit.Gpu = gpu;
        }

        public void SetRam(int ramGb)
        {
            _systemUnit.RamGb = ramGb;
        }

        public void SetStorage(string storage, int totalGb)
        {
            _systemUnit.Storage = storage;
            _systemUnit.StorageTotalGb = totalGb;
        }

        public void SetPsu(string psu)
        {
            _systemUnit.Psu = psu;
        }

        public void SetCase(string caseName)
        {
            _systemUnit.Case = caseName;
        }

        public void SetWifi(bool hasWifi)
        {
            _systemUnit.HasWifi = hasWifi;
        }

        public void SetRgb(bool hasRgb)
        {
            _systemUnit.HasRgb = hasRgb;
        }

        public void SetPrice(decimal price)
        {
            _systemUnit.Price = price;
        }

        public SystemUnit GetResult()
        {
            var result = _systemUnit;
            Reset(); 
            return result;
        }
    }
}
