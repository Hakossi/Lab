namespace _5
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Очищення ресурсів.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, створений конструктором форм Windows

        /// <summary>
        /// Мінімалістична форма без GroupBox/Panel.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTemplate = new System.Windows.Forms.Label();
            this.comboBoxTemplate = new System.Windows.Forms.ComboBox();
            this.buttonApplyTemplate = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelCpu = new System.Windows.Forms.Label();
            this.comboBoxCpu = new System.Windows.Forms.ComboBox();
            this.labelGpu = new System.Windows.Forms.Label();
            this.comboBoxGpu = new System.Windows.Forms.ComboBox();
            this.labelRam = new System.Windows.Forms.Label();
            this.numericUpDownRam = new System.Windows.Forms.NumericUpDown();
            this.labelStorage = new System.Windows.Forms.Label();
            this.comboBoxStorage = new System.Windows.Forms.ComboBox();
            this.labelPsu = new System.Windows.Forms.Label();
            this.textBoxPsu = new System.Windows.Forms.TextBox();
            this.labelCase = new System.Windows.Forms.Label();
            this.textBoxCase = new System.Windows.Forms.TextBox();
            this.checkBoxWifi = new System.Windows.Forms.CheckBox();
            this.checkBoxRgb = new System.Windows.Forms.CheckBox();
            this.labelPrice = new System.Windows.Forms.Label();
            this.numericUpDownPrice = new System.Windows.Forms.NumericUpDown();
            this.buttonBuild = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonClone = new System.Windows.Forms.Button();
            this.labelSystems = new System.Windows.Forms.Label();
            this.listBoxSystems = new System.Windows.Forms.ListBox();
            this.labelDetails = new System.Windows.Forms.Label();
            this.textBoxDetails = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTemplate
            // 
            this.labelTemplate.AutoSize = true;
            this.labelTemplate.Location = new System.Drawing.Point(12, 15);
            this.labelTemplate.Name = "labelTemplate";
            this.labelTemplate.Size = new System.Drawing.Size(113, 13);
            this.labelTemplate.TabIndex = 0;
            this.labelTemplate.Text = "Шаблон конфігурації:";
            // 
            // comboBoxTemplate
            // 
            this.comboBoxTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTemplate.FormattingEnabled = true;
            this.comboBoxTemplate.Location = new System.Drawing.Point(122, 12);
            this.comboBoxTemplate.Name = "comboBoxTemplate";
            this.comboBoxTemplate.Size = new System.Drawing.Size(160, 21);
            this.comboBoxTemplate.TabIndex = 1;
            // 
            // buttonApplyTemplate
            // 
            this.buttonApplyTemplate.Location = new System.Drawing.Point(298, 10);
            this.buttonApplyTemplate.Name = "buttonApplyTemplate";
            this.buttonApplyTemplate.Size = new System.Drawing.Size(140, 23);
            this.buttonApplyTemplate.TabIndex = 2;
            this.buttonApplyTemplate.Text = "Застосувати шаблон";
            this.buttonApplyTemplate.UseVisualStyleBackColor = true;
            this.buttonApplyTemplate.Click += new System.EventHandler(this.buttonApplyTemplate_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(12, 45);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(77, 13);
            this.labelName.TabIndex = 3;
            this.labelName.Text = "Назва збірки:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(97, 42);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(210, 20);
            this.textBoxName.TabIndex = 4;
            // 
            // labelCpu
            // 
            this.labelCpu.AutoSize = true;
            this.labelCpu.Location = new System.Drawing.Point(12, 75);
            this.labelCpu.Name = "labelCpu";
            this.labelCpu.Size = new System.Drawing.Size(32, 13);
            this.labelCpu.TabIndex = 5;
            this.labelCpu.Text = "CPU:";
            // 
            // comboBoxCpu
            // 
            this.comboBoxCpu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCpu.FormattingEnabled = true;
            this.comboBoxCpu.Location = new System.Drawing.Point(50, 72);
            this.comboBoxCpu.Name = "comboBoxCpu";
            this.comboBoxCpu.Size = new System.Drawing.Size(180, 21);
            this.comboBoxCpu.TabIndex = 6;
            // 
            // labelGpu
            // 
            this.labelGpu.AutoSize = true;
            this.labelGpu.Location = new System.Drawing.Point(250, 75);
            this.labelGpu.Name = "labelGpu";
            this.labelGpu.Size = new System.Drawing.Size(33, 13);
            this.labelGpu.TabIndex = 7;
            this.labelGpu.Text = "GPU:";
            // 
            // comboBoxGpu
            // 
            this.comboBoxGpu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGpu.FormattingEnabled = true;
            this.comboBoxGpu.Location = new System.Drawing.Point(289, 72);
            this.comboBoxGpu.Name = "comboBoxGpu";
            this.comboBoxGpu.Size = new System.Drawing.Size(210, 21);
            this.comboBoxGpu.TabIndex = 8;
            // 
            // labelRam
            // 
            this.labelRam.AutoSize = true;
            this.labelRam.Location = new System.Drawing.Point(12, 105);
            this.labelRam.Name = "labelRam";
            this.labelRam.Size = new System.Drawing.Size(56, 13);
            this.labelRam.TabIndex = 9;
            this.labelRam.Text = "RAM (ГБ):";
            // 
            // numericUpDownRam
            // 
            this.numericUpDownRam.Location = new System.Drawing.Point(77, 103);
            this.numericUpDownRam.Name = "numericUpDownRam";
            this.numericUpDownRam.Size = new System.Drawing.Size(70, 20);
            this.numericUpDownRam.TabIndex = 10;
            // 
            // labelStorage
            // 
            this.labelStorage.AutoSize = true;
            this.labelStorage.Location = new System.Drawing.Point(160, 105);
            this.labelStorage.Name = "labelStorage";
            this.labelStorage.Size = new System.Drawing.Size(75, 13);
            this.labelStorage.TabIndex = 11;
            this.labelStorage.Text = "Накопичувач:";
            // 
            // comboBoxStorage
            // 
            this.comboBoxStorage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStorage.FormattingEnabled = true;
            this.comboBoxStorage.Location = new System.Drawing.Point(232, 102);
            this.comboBoxStorage.Name = "comboBoxStorage";
            this.comboBoxStorage.Size = new System.Drawing.Size(190, 21);
            this.comboBoxStorage.TabIndex = 12;
            // 
            // labelPsu
            // 
            this.labelPsu.AutoSize = true;
            this.labelPsu.Location = new System.Drawing.Point(12, 135);
            this.labelPsu.Name = "labelPsu";
            this.labelPsu.Size = new System.Drawing.Size(67, 13);
            this.labelPsu.TabIndex = 13;
            this.labelPsu.Text = "Блок живл.:";
            // 
            // textBoxPsu
            // 
            this.textBoxPsu.Location = new System.Drawing.Point(87, 132);
            this.textBoxPsu.Name = "textBoxPsu";
            this.textBoxPsu.Size = new System.Drawing.Size(170, 20);
            this.textBoxPsu.TabIndex = 14;
            // 
            // labelCase
            // 
            this.labelCase.AutoSize = true;
            this.labelCase.Location = new System.Drawing.Point(270, 135);
            this.labelCase.Name = "labelCase";
            this.labelCase.Size = new System.Drawing.Size(46, 13);
            this.labelCase.TabIndex = 15;
            this.labelCase.Text = "Корпус:";
            // 
            // textBoxCase
            // 
            this.textBoxCase.Location = new System.Drawing.Point(329, 132);
            this.textBoxCase.Name = "textBoxCase";
            this.textBoxCase.Size = new System.Drawing.Size(170, 20);
            this.textBoxCase.TabIndex = 16;
            // 
            // checkBoxWifi
            // 
            this.checkBoxWifi.AutoSize = true;
            this.checkBoxWifi.Location = new System.Drawing.Point(15, 165);
            this.checkBoxWifi.Name = "checkBoxWifi";
            this.checkBoxWifi.Size = new System.Drawing.Size(90, 17);
            this.checkBoxWifi.TabIndex = 17;
            this.checkBoxWifi.Text = "Wi-Fi модуль";
            this.checkBoxWifi.UseVisualStyleBackColor = true;
            // 
            // checkBoxRgb
            // 
            this.checkBoxRgb.AutoSize = true;
            this.checkBoxRgb.Location = new System.Drawing.Point(112, 165);
            this.checkBoxRgb.Name = "checkBoxRgb";
            this.checkBoxRgb.Size = new System.Drawing.Size(97, 17);
            this.checkBoxRgb.TabIndex = 18;
            this.checkBoxRgb.Text = "RGB підсвітка";
            this.checkBoxRgb.UseVisualStyleBackColor = true;
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Location = new System.Drawing.Point(220, 165);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(58, 13);
            this.labelPrice.TabIndex = 19;
            this.labelPrice.Text = "Ціна (грн):";
            // 
            // numericUpDownPrice
            // 
            this.numericUpDownPrice.Location = new System.Drawing.Point(289, 163);
            this.numericUpDownPrice.Name = "numericUpDownPrice";
            this.numericUpDownPrice.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownPrice.TabIndex = 20;
            // 
            // buttonBuild
            // 
            this.buttonBuild.Location = new System.Drawing.Point(15, 195);
            this.buttonBuild.Name = "buttonBuild";
            this.buttonBuild.Size = new System.Drawing.Size(180, 23);
            this.buttonBuild.TabIndex = 21;
            this.buttonBuild.Text = "Побудувати системний блок";
            this.buttonBuild.UseVisualStyleBackColor = true;
            this.buttonBuild.Click += new System.EventHandler(this.buttonBuild_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(210, 195);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(140, 23);
            this.buttonClear.TabIndex = 22;
            this.buttonClear.Text = "Очистити список";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonClone
            // 
            this.buttonClone.Location = new System.Drawing.Point(365, 195);
            this.buttonClone.Name = "buttonClone";
            this.buttonClone.Size = new System.Drawing.Size(134, 23);
            this.buttonClone.TabIndex = 23;
            this.buttonClone.Text = "Клонувати вибрану";
            this.buttonClone.UseVisualStyleBackColor = true;
            this.buttonClone.Click += new System.EventHandler(this.buttonClone_Click);
            // 
            // labelSystems
            // 
            this.labelSystems.AutoSize = true;
            this.labelSystems.Location = new System.Drawing.Point(12, 230);
            this.labelSystems.Name = "labelSystems";
            this.labelSystems.Size = new System.Drawing.Size(82, 13);
            this.labelSystems.TabIndex = 24;
            this.labelSystems.Text = "Список збірок:";
            // 
            // listBoxSystems
            // 
            this.listBoxSystems.FormattingEnabled = true;
            this.listBoxSystems.Location = new System.Drawing.Point(15, 250);
            this.listBoxSystems.Name = "listBoxSystems";
            this.listBoxSystems.Size = new System.Drawing.Size(280, 160);
            this.listBoxSystems.TabIndex = 25;
            this.listBoxSystems.SelectedIndexChanged += new System.EventHandler(this.listBoxSystems_SelectedIndexChanged);
            // 
            // labelDetails
            // 
            this.labelDetails.AutoSize = true;
            this.labelDetails.Location = new System.Drawing.Point(310, 230);
            this.labelDetails.Name = "labelDetails";
            this.labelDetails.Size = new System.Drawing.Size(127, 13);
            this.labelDetails.TabIndex = 26;
            this.labelDetails.Text = "Деталі вибраної збірки:";
            // 
            // textBoxDetails
            // 
            this.textBoxDetails.Location = new System.Drawing.Point(313, 250);
            this.textBoxDetails.Multiline = true;
            this.textBoxDetails.Name = "textBoxDetails";
            this.textBoxDetails.ReadOnly = true;
            this.textBoxDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDetails.Size = new System.Drawing.Size(260, 160);
            this.textBoxDetails.TabIndex = 27;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(594, 451);
            this.Controls.Add(this.textBoxDetails);
            this.Controls.Add(this.labelDetails);
            this.Controls.Add(this.listBoxSystems);
            this.Controls.Add(this.labelSystems);
            this.Controls.Add(this.buttonClone);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonBuild);
            this.Controls.Add(this.numericUpDownPrice);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.checkBoxRgb);
            this.Controls.Add(this.checkBoxWifi);
            this.Controls.Add(this.textBoxCase);
            this.Controls.Add(this.labelCase);
            this.Controls.Add(this.textBoxPsu);
            this.Controls.Add(this.labelPsu);
            this.Controls.Add(this.comboBoxStorage);
            this.Controls.Add(this.labelStorage);
            this.Controls.Add(this.numericUpDownRam);
            this.Controls.Add(this.labelRam);
            this.Controls.Add(this.comboBoxGpu);
            this.Controls.Add(this.labelGpu);
            this.Controls.Add(this.comboBoxCpu);
            this.Controls.Add(this.labelCpu);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.buttonApplyTemplate);
            this.Controls.Add(this.comboBoxTemplate);
            this.Controls.Add(this.labelTemplate);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTemplate;
        private System.Windows.Forms.ComboBox comboBoxTemplate;
        private System.Windows.Forms.Button buttonApplyTemplate;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelCpu;
        private System.Windows.Forms.ComboBox comboBoxCpu;
        private System.Windows.Forms.Label labelGpu;
        private System.Windows.Forms.ComboBox comboBoxGpu;
        private System.Windows.Forms.Label labelRam;
        private System.Windows.Forms.NumericUpDown numericUpDownRam;
        private System.Windows.Forms.Label labelStorage;
        private System.Windows.Forms.ComboBox comboBoxStorage;
        private System.Windows.Forms.Label labelPsu;
        private System.Windows.Forms.TextBox textBoxPsu;
        private System.Windows.Forms.Label labelCase;
        private System.Windows.Forms.TextBox textBoxCase;
        private System.Windows.Forms.CheckBox checkBoxWifi;
        private System.Windows.Forms.CheckBox checkBoxRgb;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.NumericUpDown numericUpDownPrice;
        private System.Windows.Forms.Button buttonBuild;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonClone;
        private System.Windows.Forms.Label labelSystems;
        private System.Windows.Forms.ListBox listBoxSystems;
        private System.Windows.Forms.Label labelDetails;
        private System.Windows.Forms.TextBox textBoxDetails;
    }
}
