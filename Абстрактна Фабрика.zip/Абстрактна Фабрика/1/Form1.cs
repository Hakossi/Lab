using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace _1
{
    public partial class Form1 : Form
    {
        // Як студент 4 курсу, стараюсь зробити все максимально читабельно :)
        private readonly Dictionary<string, IBeautySalonFactory> _factories =
            new Dictionary<string, IBeautySalonFactory>();

        private readonly List<string> _currentPackageDetails = new List<string>();

        public Form1()
        {
            InitializeComponent();
            InitFactories();
            InitControls();
        }

        private void InitFactories()
        {
            _factories["Класичний салон"] = new ClassicBeautySalonFactory();
            _factories["Преміум салон"] = new LuxuryBeautySalonFactory();
        }

        private void InitControls()
        {
            comboBoxSalon.Items.Clear();
            comboBoxSalon.Items.Add("Класичний салон");
            comboBoxSalon.Items.Add("Преміум салон");
            comboBoxSalon.SelectedIndex = 0;

            checkBoxHair.Checked = true;
            checkBoxNails.Checked = true;
            checkBoxMakeup.Checked = true;

            UpdateInfo(null);
        }

        private void buttonCreatePackage_Click(object sender, EventArgs e)
        {
            string key = comboBoxSalon.SelectedItem as string;
            if (string.IsNullOrEmpty(key) || !_factories.ContainsKey(key))
            {
                MessageBox.Show("Оберіть тип салону.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var factory = _factories[key];
            _currentPackageDetails.Clear();
            listBoxServices.Items.Clear();

            decimal totalPrice = 0;
            int totalDuration = 0;

            if (checkBoxHair.Checked)
            {
                var hair = factory.CreateHairService();
                listBoxServices.Items.Add("[Волосся] " + hair.Name);
                _currentPackageDetails.Add(hair.GetDescription());
                totalPrice += hair.Price;
                totalDuration += hair.DurationMinutes;
            }

            if (checkBoxNails.Checked)
            {
                var nails = factory.CreateNailService();
                listBoxServices.Items.Add("[Нігті] " + nails.Name);
                _currentPackageDetails.Add(nails.GetDescription());
                totalPrice += nails.Price;
                totalDuration += nails.DurationMinutes;
            }

            if (checkBoxMakeup.Checked)
            {
                var makeup = factory.CreateMakeupService();
                listBoxServices.Items.Add("[Макіяж] " + makeup.Name);
                _currentPackageDetails.Add(makeup.GetDescription());
                totalPrice += makeup.Price;
                totalDuration += makeup.DurationMinutes;
            }

            UpdateInfo(factory, totalPrice, totalDuration);
        }

        private void listBoxServices_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBoxServices.SelectedIndex;
            if (index >= 0 && index < _currentPackageDetails.Count)
            {
                textBoxDetails.Text = _currentPackageDetails[index];
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            listBoxServices.Items.Clear();
            _currentPackageDetails.Clear();
            textBoxDetails.Clear();
            UpdateInfo(null);
        }

        private void UpdateInfo(IBeautySalonFactory factory, decimal totalPrice = 0, int totalDuration = 0)
        {
            if (factory == null || listBoxServices.Items.Count == 0)
            {
                labelSummary.Text = "Пакет ще не сформовано.";
            }
            else
            {
                var sb = new StringBuilder();
                sb.Append(factory.SalonName);
                sb.Append(" | Послуг у пакеті: ");
                sb.Append(listBoxServices.Items.Count);
                sb.Append(" | Загальна вартість: ");
                sb.Append(totalPrice);
                sb.Append(" грн | Орієнтовний час: ");
                sb.Append(totalDuration);
                sb.Append(" хв");

                labelSummary.Text = sb.ToString();
            }
        }
    }
}
