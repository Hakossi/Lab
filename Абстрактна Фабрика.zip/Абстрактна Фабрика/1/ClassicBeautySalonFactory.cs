namespace _1
{
    
    public class ClassicBeautySalonFactory : IBeautySalonFactory
    {
        public string SalonName => "Класичний салон";

        public IHairService CreateHairService()
        {
            return new ClassicHairService();
        }

        public INailService CreateNailService()
        {
            return new ClassicNailService();
        }

        public IMakeupService CreateMakeupService()
        {
            return new ClassicMakeupService();
        }
    }
}
