namespace _1
{


    public interface IBeautySalonFactory
    {
        IHairService CreateHairService();
        INailService CreateNailService();
        IMakeupService CreateMakeupService();
        string SalonName { get; }
    }
}
