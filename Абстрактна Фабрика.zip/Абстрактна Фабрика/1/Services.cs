namespace _1
{


    public interface IHairService
    {
        string Name { get; }
        decimal Price { get; }
        int DurationMinutes { get; }
        string GetDescription();
    }

    public interface INailService
    {
        string Name { get; }
        decimal Price { get; }
        int DurationMinutes { get; }
        string GetDescription();
    }

    public interface IMakeupService
    {
        string Name { get; }
        decimal Price { get; }
        int DurationMinutes { get; }
        string GetDescription();
    }

   
    public class ClassicHairService : IHairService
    {
        public string Name => "Стрижка базова";
        public decimal Price => 250;
        public int DurationMinutes => 40;

        public string GetDescription()
        {
            return $"{Name} – проста стрижка без складного укладання. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }

    public class ClassicNailService : INailService
    {
        public string Name => "Манікюр класичний";
        public decimal Price => 200;
        public int DurationMinutes => 50;

        public string GetDescription()
        {
            return $"{Name} – акуратний манікюр без складного дизайну. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }

    public class ClassicMakeupService : IMakeupService
    {
        public string Name => "Денний макіяж";
        public decimal Price => 300;
        public int DurationMinutes => 45;

        public string GetDescription()
        {
            return $"{Name} – легкий повсякденний макіяж. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }


    public class LuxuryHairService : IHairService
    {
        public string Name => "Стрижка + укладання преміум";
        public decimal Price => 700;
        public int DurationMinutes => 70;

        public string GetDescription()
        {
            return $"{Name} – догляд, стрижка, укладання, термозахист. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }

    public class LuxuryNailService : INailService
    {
        public string Name => "Манікюр з покриттям гель-лаком";
        public decimal Price => 600;
        public int DurationMinutes => 90;

        public string GetDescription()
        {
            return $"{Name} – манікюр, укріплення і гель-лак. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }

    public class LuxuryMakeupService : IMakeupService
    {
        public string Name => "Вечірній макіяж";
        public decimal Price => 900;
        public int DurationMinutes => 75;

        public string GetDescription()
        {
            return $"{Name} – виразний вечірній образ. Ціна {Price} грн, {DurationMinutes} хв.";
        }
    }
}
