namespace _1
{

    public class LuxuryBeautySalonFactory : IBeautySalonFactory
    {
        public string SalonName => "Преміум салон";

        public IHairService CreateHairService()
        {
            return new LuxuryHairService();
        }

        public INailService CreateNailService()
        {
            return new LuxuryNailService();
        }

        public IMakeupService CreateMakeupService()
        {
            return new LuxuryMakeupService();
        }
    }
}
