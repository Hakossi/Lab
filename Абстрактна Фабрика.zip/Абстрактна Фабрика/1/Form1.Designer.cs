namespace _1
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Чистимо за собою ресурси.
        /// </summary>
        /// <param name="disposing">true, якщо керовані ресурси слід видалити; інакше false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, створений конструктором форм Windows

        /// <summary>
        /// Стандартний метод для ініціалізації контролів.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelSalonType = new System.Windows.Forms.Label();
            this.comboBoxSalon = new System.Windows.Forms.ComboBox();
            this.checkBoxHair = new System.Windows.Forms.CheckBox();
            this.checkBoxNails = new System.Windows.Forms.CheckBox();
            this.checkBoxMakeup = new System.Windows.Forms.CheckBox();
            this.buttonCreatePackage = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.labelServices = new System.Windows.Forms.Label();
            this.listBoxServices = new System.Windows.Forms.ListBox();
            this.labelDetails = new System.Windows.Forms.Label();
            this.textBoxDetails = new System.Windows.Forms.TextBox();
            this.labelSummary = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelSalonType
            // 
            this.labelSalonType.AutoSize = true;
            this.labelSalonType.Location = new System.Drawing.Point(13, 84);
            this.labelSalonType.Name = "labelSalonType";
            this.labelSalonType.Size = new System.Drawing.Size(67, 13);
            this.labelSalonType.TabIndex = 0;
            this.labelSalonType.Text = "Тип салону:";
            // 
            // comboBoxSalon
            // 
            this.comboBoxSalon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSalon.FormattingEnabled = true;
            this.comboBoxSalon.Location = new System.Drawing.Point(87, 81);
            this.comboBoxSalon.Name = "comboBoxSalon";
            this.comboBoxSalon.Size = new System.Drawing.Size(180, 21);
            this.comboBoxSalon.TabIndex = 1;
            // 
            // checkBoxHair
            // 
            this.checkBoxHair.AutoSize = true;
            this.checkBoxHair.Location = new System.Drawing.Point(17, 58);
            this.checkBoxHair.Name = "checkBoxHair";
            this.checkBoxHair.Size = new System.Drawing.Size(134, 17);
            this.checkBoxHair.TabIndex = 2;
            this.checkBoxHair.Text = "Послуги для волосся";
            this.checkBoxHair.UseVisualStyleBackColor = true;
            // 
            // checkBoxNails
            // 
            this.checkBoxNails.AutoSize = true;
            this.checkBoxNails.Location = new System.Drawing.Point(17, 12);
            this.checkBoxNails.Name = "checkBoxNails";
            this.checkBoxNails.Size = new System.Drawing.Size(100, 17);
            this.checkBoxNails.TabIndex = 3;
            this.checkBoxNails.Text = "Манікюр / нігті";
            this.checkBoxNails.UseVisualStyleBackColor = true;
            // 
            // checkBoxMakeup
            // 
            this.checkBoxMakeup.AutoSize = true;
            this.checkBoxMakeup.Location = new System.Drawing.Point(17, 35);
            this.checkBoxMakeup.Name = "checkBoxMakeup";
            this.checkBoxMakeup.Size = new System.Drawing.Size(63, 17);
            this.checkBoxMakeup.TabIndex = 4;
            this.checkBoxMakeup.Text = "Макіяж";
            this.checkBoxMakeup.UseVisualStyleBackColor = true;
            // 
            // buttonCreatePackage
            // 
            this.buttonCreatePackage.Location = new System.Drawing.Point(17, 118);
            this.buttonCreatePackage.Name = "buttonCreatePackage";
            this.buttonCreatePackage.Size = new System.Drawing.Size(180, 23);
            this.buttonCreatePackage.TabIndex = 5;
            this.buttonCreatePackage.Text = "Сформувати пакет послуг";
            this.buttonCreatePackage.UseVisualStyleBackColor = true;
            this.buttonCreatePackage.Click += new System.EventHandler(this.buttonCreatePackage_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(17, 151);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(180, 23);
            this.buttonClear.TabIndex = 6;
            this.buttonClear.Text = "Очистити";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // labelServices
            // 
            this.labelServices.AutoSize = true;
            this.labelServices.Location = new System.Drawing.Point(111, 86);
            this.labelServices.Name = "labelServices";
            this.labelServices.Size = new System.Drawing.Size(78, 13);
            this.labelServices.TabIndex = 7;
            this.labelServices.Text = "Склад пакету:";
            // 
            // listBoxServices
            // 
            this.listBoxServices.FormattingEnabled = true;
            this.listBoxServices.Location = new System.Drawing.Point(114, 106);
            this.listBoxServices.Name = "listBoxServices";
            this.listBoxServices.Size = new System.Drawing.Size(260, 108);
            this.listBoxServices.TabIndex = 8;
            this.listBoxServices.SelectedIndexChanged += new System.EventHandler(this.listBoxServices_SelectedIndexChanged);
            // 
            // labelDetails
            // 
            this.labelDetails.AutoSize = true;
            this.labelDetails.Location = new System.Drawing.Point(540, 90);
            this.labelDetails.Name = "labelDetails";
            this.labelDetails.Size = new System.Drawing.Size(135, 13);
            this.labelDetails.TabIndex = 9;
            this.labelDetails.Text = "Деталі вибраної послуги:";
            // 
            // textBoxDetails
            // 
            this.textBoxDetails.Location = new System.Drawing.Point(543, 106);
            this.textBoxDetails.Multiline = true;
            this.textBoxDetails.Name = "textBoxDetails";
            this.textBoxDetails.ReadOnly = true;
            this.textBoxDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDetails.Size = new System.Drawing.Size(237, 108);
            this.textBoxDetails.TabIndex = 10;
            // 
            // labelSummary
            // 
            this.labelSummary.AutoSize = true;
            this.labelSummary.Location = new System.Drawing.Point(290, 41);
            this.labelSummary.Name = "labelSummary";
            this.labelSummary.Size = new System.Drawing.Size(141, 13);
            this.labelSummary.TabIndex = 11;
            this.labelSummary.Text = "Пакет ще не сформовано.";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxMakeup);
            this.panel1.Controls.Add(this.checkBoxNails);
            this.panel1.Controls.Add(this.checkBoxHair);
            this.panel1.Controls.Add(this.comboBoxSalon);
            this.panel1.Controls.Add(this.labelSalonType);
            this.panel1.Controls.Add(this.buttonCreatePackage);
            this.panel1.Controls.Add(this.buttonClear);
            this.panel1.Location = new System.Drawing.Point(314, 245);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(281, 207);
            this.panel1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 549);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.labelSummary);
            this.Controls.Add(this.textBoxDetails);
            this.Controls.Add(this.labelDetails);
            this.Controls.Add(this.listBoxServices);
            this.Controls.Add(this.labelServices);
            this.Name = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSalonType;
        private System.Windows.Forms.ComboBox comboBoxSalon;
        private System.Windows.Forms.CheckBox checkBoxHair;
        private System.Windows.Forms.CheckBox checkBoxNails;
        private System.Windows.Forms.CheckBox checkBoxMakeup;
        private System.Windows.Forms.Button buttonCreatePackage;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label labelServices;
        private System.Windows.Forms.ListBox listBoxServices;
        private System.Windows.Forms.Label labelDetails;
        private System.Windows.Forms.TextBox textBoxDetails;
        private System.Windows.Forms.Label labelSummary;
        private System.Windows.Forms.Panel panel1;
    }
}
