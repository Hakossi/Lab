using System.Collections.Generic;

namespace Lab9
{
    public class SubmarineConfig
    {
        public HullType Hull { get; set; }
        public PropulsionType Propulsion { get; set; }
        public PowerPlantType PowerPlant { get; set; }
        public SonarType Sonar { get; set; }
        public LivingModuleType LivingModule { get; set; }
        public int Crew { get; set; }
        public List<WeaponType> Weapons { get; } = new List<WeaponType>();
    }
}
