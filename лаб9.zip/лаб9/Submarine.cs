using System.Collections.Generic;
using System.Text;

namespace Lab9
{
    public class Submarine
    {
        public HullType Hull { get; set; }
        public PropulsionType Propulsion { get; set; }
        public PowerPlantType PowerPlant { get; set; }
        public SonarType Sonar { get; set; }
        public LivingModuleType LivingModule { get; set; }
        public int Crew { get; set; }

        public List<WeaponType> Weapons { get; } = new List<WeaponType>();

        public int EstimatedCostMillionUsd { get; set; }

        public string Describe()
        {
            var sb = new StringBuilder();
            sb.AppendLine("ПІДВОДНИЙ ЧОВЕН (зібрано Компонувальником)");
            sb.AppendLine($"Корпус: {ToUa(Hull)}");
            sb.AppendLine($"Рушій: {ToUa(Propulsion)}");
            sb.AppendLine($"Енергоустановка: {ToUa(PowerPlant)}");
            sb.AppendLine($"Сонар: {ToUa(Sonar)}");
            sb.AppendLine($"Житловий модуль: {ToUa(LivingModule)}");
            sb.AppendLine($"Екіпаж: {Crew}");
            sb.AppendLine("Озброєння:");
            if (Weapons.Count == 0)
                sb.AppendLine("  - немає");
            else
                foreach (var w in Weapons)
                    sb.AppendLine($"  - {ToUa(w)}");

            sb.AppendLine($"Орієнтовна вартість: {EstimatedCostMillionUsd} млн $");
            return sb.ToString();
        }

        private static string ToUa(HullType t)
        {
            switch (t)
            {
                case HullType.Light: return "Легкий";
                case HullType.Reinforced: return "Посилений";
                case HullType.Stealth: return "Стелс";
                default: return t.ToString();
            }
        }

        private static string ToUa(PropulsionType t)
        {
            switch (t)
            {
                case PropulsionType.Screw: return "Гвинт";
                case PropulsionType.PumpJet: return "Pump-jet";
                case PropulsionType.Hybrid: return "Гібрид";
                default: return t.ToString();
            }
        }

        private static string ToUa(PowerPlantType t)
        {
            switch (t)
            {
                case PowerPlantType.DieselElectric: return "Дизель-електрична";
                case PowerPlantType.Nuclear: return "Ядерна";
                case PowerPlantType.AIP: return "AIP (повітронезалежна)";
                default: return t.ToString();
            }
        }

        private static string ToUa(SonarType t)
        {
            switch (t)
            {
                case SonarType.Basic: return "Базовий";
                case SonarType.TowedArray: return "Буксирована антена";
                case SonarType.Advanced: return "Просунутий";
                default: return t.ToString();
            }
        }

        private static string ToUa(WeaponType t)
        {
            switch (t)
            {
                case WeaponType.Torpedoes: return "Торпеди";
                case WeaponType.CruiseMissiles: return "Крилаті ракети";
                case WeaponType.Mines: return "Міни";
                default: return t.ToString();
            }
        }

        private static string ToUa(LivingModuleType t)
        {
            switch (t)
            {
                case LivingModuleType.Standard: return "Стандартний";
                case LivingModuleType.ExtendedRange: return "Для дальніх походів";
                case LivingModuleType.Research: return "Дослідницький";
                default: return t.ToString();
            }
        }
    }
}
