using System;

namespace Lab9
{
    public class SubmarineBuilder : ISubmarineBuilder
    {
        private Submarine _submarine;

        public SubmarineBuilder()
        {
            Reset();
        }

        public void Reset()
        {
            _submarine = new Submarine
            {
                Hull = HullType.Light,
                Propulsion = PropulsionType.Screw,
                PowerPlant = PowerPlantType.DieselElectric,
                Sonar = SonarType.Basic,
                LivingModule = LivingModuleType.Standard,
                Crew = 30,
                EstimatedCostMillionUsd = 250
            };
        }

        public void SetHull(HullType hull)
        {
            _submarine.Hull = hull;
            _submarine.EstimatedCostMillionUsd += hull == HullType.Stealth ? 200 :
                                                hull == HullType.Reinforced ? 120 : 60;
        }

        public void SetPropulsion(PropulsionType propulsion)
        {
            _submarine.Propulsion = propulsion;
            _submarine.EstimatedCostMillionUsd += propulsion == PropulsionType.PumpJet ? 140 :
                                                propulsion == PropulsionType.Hybrid ? 110 : 70;
        }

        public void SetPowerPlant(PowerPlantType powerPlant)
        {
            _submarine.PowerPlant = powerPlant;
            _submarine.EstimatedCostMillionUsd += powerPlant == PowerPlantType.Nuclear ? 450 :
                                                powerPlant == PowerPlantType.AIP ? 220 : 120;
        }

        public void SetSonar(SonarType sonar)
        {
            _submarine.Sonar = sonar;
            _submarine.EstimatedCostMillionUsd += sonar == SonarType.Advanced ? 160 :
                                                sonar == SonarType.TowedArray ? 120 : 60;
        }

        public void SetLivingModule(LivingModuleType module)
        {
            _submarine.LivingModule = module;
            _submarine.EstimatedCostMillionUsd += module == LivingModuleType.ExtendedRange ? 90 :
                                                module == LivingModuleType.Research ? 110 : 60;
        }

        public void SetCrew(int crew)
        {
            _submarine.Crew = Math.Max(10, crew);
            _submarine.EstimatedCostMillionUsd += _submarine.Crew / 2;
        }

        public void AddWeapon(WeaponType weapon)
        {
            _submarine.Weapons.Add(weapon);
            _submarine.EstimatedCostMillionUsd += weapon == WeaponType.CruiseMissiles ? 180 :
                                                weapon == WeaponType.Mines ? 90 : 120;
        }

        public Submarine GetResult()
        {
            var result = _submarine;
     
            Reset();
            return result;
        }
    }
}
