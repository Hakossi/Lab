namespace Lab9
{
    public class SubmarineDirector
    {
        public Submarine Construct(ISubmarineBuilder builder, SubmarineConfig cfg)
        {
            builder.Reset();

            builder.SetHull(cfg.Hull);
            builder.SetPowerPlant(cfg.PowerPlant);
            builder.SetPropulsion(cfg.Propulsion);
            builder.SetSonar(cfg.Sonar);
            builder.SetLivingModule(cfg.LivingModule);
            builder.SetCrew(cfg.Crew);

            foreach (var w in cfg.Weapons)
                builder.AddWeapon(w);

            return builder.GetResult();
        }

       
        public Submarine ConstructAttack(ISubmarineBuilder builder)
        {
            var cfg = new SubmarineConfig
            {
                Hull = HullType.Stealth,
                PowerPlant = PowerPlantType.Nuclear,
                Propulsion = PropulsionType.PumpJet,
                Sonar = SonarType.Advanced,
                LivingModule = LivingModuleType.Standard,
                Crew = 65
            };
            cfg.Weapons.Add(WeaponType.Torpedoes);
            cfg.Weapons.Add(WeaponType.CruiseMissiles);
            return Construct(builder, cfg);
        }

        public Submarine ConstructPatrol(ISubmarineBuilder builder)
        {
            var cfg = new SubmarineConfig
            {
                Hull = HullType.Reinforced,
                PowerPlant = PowerPlantType.DieselElectric,
                Propulsion = PropulsionType.Screw,
                Sonar = SonarType.TowedArray,
                LivingModule = LivingModuleType.ExtendedRange,
                Crew = 45
            };
            cfg.Weapons.Add(WeaponType.Torpedoes);
            cfg.Weapons.Add(WeaponType.Mines);
            return Construct(builder, cfg);
        }
    }
}
