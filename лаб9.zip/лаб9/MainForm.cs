using System;
using System.Linq;
using System.Windows.Forms;

namespace Lab9
{
    public partial class MainForm : Form
    {
        private readonly SubmarineDirector _director = new SubmarineDirector();
        private readonly ISubmarineBuilder _builder = new SubmarineBuilder();
        private readonly Random _rnd = new Random();

        public MainForm()
        {
            InitializeComponent();
            InitUi();
        }

        private void InitUi()
        {
            // Заповнення ComboBox'ів (простим способом)
            cbHull.DataSource = Enum.GetValues(typeof(HullType));
            cbPropulsion.DataSource = Enum.GetValues(typeof(PropulsionType));
            cbPower.DataSource = Enum.GetValues(typeof(PowerPlantType));
            cbSonar.DataSource = Enum.GetValues(typeof(SonarType));
            cbLiving.DataSource = Enum.GetValues(typeof(LivingModuleType));

            clbWeapons.Items.Clear();
            foreach (var w in Enum.GetValues(typeof(WeaponType)))
                clbWeapons.Items.Add(w);

            nudCrew.Minimum = 10;
            nudCrew.Maximum = 120;
            nudCrew.Value = 45;

            btnBuild.Click += BtnBuild_Click;
            btnPresetAttack.Click += BtnPresetAttack_Click;
            btnPresetPatrol.Click += BtnPresetPatrol_Click;
            btnRandom.Click += BtnRandom_Click;
            btnClear.Click += (s, e) => txtOutput.Clear();
        }

        private void BtnBuild_Click(object sender, EventArgs e)
        {
            var cfg = ReadConfigFromUi();
            var sub = _director.Construct(_builder, cfg);
            txtOutput.Text = sub.Describe();
        }

        private void BtnPresetAttack_Click(object sender, EventArgs e)
        {
            var sub = _director.ConstructAttack(_builder);
            txtOutput.Text = sub.Describe();
        }

        private void BtnPresetPatrol_Click(object sender, EventArgs e)
        {
            var sub = _director.ConstructPatrol(_builder);
            txtOutput.Text = sub.Describe();
        }

        private void BtnRandom_Click(object sender, EventArgs e)
        {
            cbHull.SelectedIndex = _rnd.Next(cbHull.Items.Count);
            cbPropulsion.SelectedIndex = _rnd.Next(cbPropulsion.Items.Count);
            cbPower.SelectedIndex = _rnd.Next(cbPower.Items.Count);
            cbSonar.SelectedIndex = _rnd.Next(cbSonar.Items.Count);
            cbLiving.SelectedIndex = _rnd.Next(cbLiving.Items.Count);

            nudCrew.Value = _rnd.Next(20, 90);

            for (int i = 0; i < clbWeapons.Items.Count; i++)
                clbWeapons.SetItemChecked(i, _rnd.NextDouble() < 0.5);

            txtOutput.Clear();
        }

        private SubmarineConfig ReadConfigFromUi()
        {
            var cfg = new SubmarineConfig
            {
                Hull = (HullType)cbHull.SelectedItem,
                Propulsion = (PropulsionType)cbPropulsion.SelectedItem,
                PowerPlant = (PowerPlantType)cbPower.SelectedItem,
                Sonar = (SonarType)cbSonar.SelectedItem,
                LivingModule = (LivingModuleType)cbLiving.SelectedItem,
                Crew = (int)nudCrew.Value
            };

            cfg.Weapons.Clear();
            var checkedItems = clbWeapons.CheckedItems.Cast<object>().ToList();
            foreach (var item in checkedItems)
                cfg.Weapons.Add((WeaponType)item);

            return cfg;
        }
    }
}
