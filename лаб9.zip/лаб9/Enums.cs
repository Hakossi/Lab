namespace Lab9
{
    public enum HullType
    {
        Light,
        Reinforced,
        Stealth
    }

    public enum PropulsionType
    {
        Screw,
        PumpJet,
        Hybrid
    }

    public enum PowerPlantType
    {
        DieselElectric,
        Nuclear,
        AIP
    }

    public enum SonarType
    {
        Basic,
        TowedArray,
        Advanced
    }

    public enum WeaponType
    {
        Torpedoes,
        CruiseMissiles,
        Mines
    }

    public enum LivingModuleType
    {
        Standard,
        ExtendedRange,
        Research
    }
}
