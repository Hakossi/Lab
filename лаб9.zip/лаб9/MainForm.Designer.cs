namespace Lab9
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblHull;
        private System.Windows.Forms.Label lblPropulsion;
        private System.Windows.Forms.Label lblPower;
        private System.Windows.Forms.Label lblSonar;
        private System.Windows.Forms.Label lblLiving;
        private System.Windows.Forms.Label lblWeapons;
        private System.Windows.Forms.Label lblCrew;

        private System.Windows.Forms.ComboBox cbHull;
        private System.Windows.Forms.ComboBox cbPropulsion;
        private System.Windows.Forms.ComboBox cbPower;
        private System.Windows.Forms.ComboBox cbSonar;
        private System.Windows.Forms.ComboBox cbLiving;

        private System.Windows.Forms.CheckedListBox clbWeapons;
        private System.Windows.Forms.NumericUpDown nudCrew;

        private System.Windows.Forms.Button btnBuild;
        private System.Windows.Forms.Button btnPresetAttack;
        private System.Windows.Forms.Button btnPresetPatrol;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnClear;

        private System.Windows.Forms.TextBox txtOutput;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblHull = new System.Windows.Forms.Label();
            this.lblPropulsion = new System.Windows.Forms.Label();
            this.lblPower = new System.Windows.Forms.Label();
            this.lblSonar = new System.Windows.Forms.Label();
            this.lblLiving = new System.Windows.Forms.Label();
            this.lblWeapons = new System.Windows.Forms.Label();
            this.lblCrew = new System.Windows.Forms.Label();
            this.cbHull = new System.Windows.Forms.ComboBox();
            this.cbPropulsion = new System.Windows.Forms.ComboBox();
            this.cbPower = new System.Windows.Forms.ComboBox();
            this.cbSonar = new System.Windows.Forms.ComboBox();
            this.cbLiving = new System.Windows.Forms.ComboBox();
            this.clbWeapons = new System.Windows.Forms.CheckedListBox();
            this.nudCrew = new System.Windows.Forms.NumericUpDown();
            this.btnBuild = new System.Windows.Forms.Button();
            this.btnPresetAttack = new System.Windows.Forms.Button();
            this.btnPresetPatrol = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudCrew)).BeginInit();
            this.SuspendLayout();
            // 
            // lblHull
            // 
            this.lblHull.AutoSize = true;
            this.lblHull.Location = new System.Drawing.Point(13, 45);
            this.lblHull.Name = "lblHull";
            this.lblHull.Size = new System.Drawing.Size(46, 13);
            this.lblHull.TabIndex = 1;
            this.lblHull.Text = "Корпус:";
            // 
            // lblPropulsion
            // 
            this.lblPropulsion.AutoSize = true;
            this.lblPropulsion.Location = new System.Drawing.Point(13, 72);
            this.lblPropulsion.Name = "lblPropulsion";
            this.lblPropulsion.Size = new System.Drawing.Size(38, 13);
            this.lblPropulsion.TabIndex = 3;
            this.lblPropulsion.Text = "Рушій:";
            // 
            // lblPower
            // 
            this.lblPower.AutoSize = true;
            this.lblPower.Location = new System.Drawing.Point(13, 99);
            this.lblPower.Name = "lblPower";
            this.lblPower.Size = new System.Drawing.Size(98, 13);
            this.lblPower.TabIndex = 5;
            this.lblPower.Text = "Енергоустановка:";
            // 
            // lblSonar
            // 
            this.lblSonar.AutoSize = true;
            this.lblSonar.Location = new System.Drawing.Point(13, 126);
            this.lblSonar.Name = "lblSonar";
            this.lblSonar.Size = new System.Drawing.Size(41, 13);
            this.lblSonar.TabIndex = 7;
            this.lblSonar.Text = "Сонар:";
            // 
            // lblLiving
            // 
            this.lblLiving.AutoSize = true;
            this.lblLiving.Location = new System.Drawing.Point(13, 153);
            this.lblLiving.Name = "lblLiving";
            this.lblLiving.Size = new System.Drawing.Size(102, 13);
            this.lblLiving.TabIndex = 9;
            this.lblLiving.Text = "Житловий модуль:";
            // 
            // lblWeapons
            // 
            this.lblWeapons.AutoSize = true;
            this.lblWeapons.Location = new System.Drawing.Point(13, 210);
            this.lblWeapons.Name = "lblWeapons";
            this.lblWeapons.Size = new System.Drawing.Size(66, 13);
            this.lblWeapons.TabIndex = 13;
            this.lblWeapons.Text = "Озброєння:";
            // 
            // lblCrew
            // 
            this.lblCrew.AutoSize = true;
            this.lblCrew.Location = new System.Drawing.Point(13, 180);
            this.lblCrew.Name = "lblCrew";
            this.lblCrew.Size = new System.Drawing.Size(45, 13);
            this.lblCrew.TabIndex = 11;
            this.lblCrew.Text = "Екіпаж:";
            // 
            // cbHull
            // 
            this.cbHull.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbHull.FormattingEnabled = true;
            this.cbHull.Location = new System.Drawing.Point(150, 42);
            this.cbHull.Name = "cbHull";
            this.cbHull.Size = new System.Drawing.Size(200, 21);
            this.cbHull.TabIndex = 2;
            // 
            // cbPropulsion
            // 
            this.cbPropulsion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPropulsion.FormattingEnabled = true;
            this.cbPropulsion.Location = new System.Drawing.Point(150, 69);
            this.cbPropulsion.Name = "cbPropulsion";
            this.cbPropulsion.Size = new System.Drawing.Size(200, 21);
            this.cbPropulsion.TabIndex = 4;
            // 
            // cbPower
            // 
            this.cbPower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPower.FormattingEnabled = true;
            this.cbPower.Location = new System.Drawing.Point(150, 96);
            this.cbPower.Name = "cbPower";
            this.cbPower.Size = new System.Drawing.Size(200, 21);
            this.cbPower.TabIndex = 6;
            // 
            // cbSonar
            // 
            this.cbSonar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSonar.FormattingEnabled = true;
            this.cbSonar.Location = new System.Drawing.Point(150, 123);
            this.cbSonar.Name = "cbSonar";
            this.cbSonar.Size = new System.Drawing.Size(200, 21);
            this.cbSonar.TabIndex = 8;
            // 
            // cbLiving
            // 
            this.cbLiving.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLiving.FormattingEnabled = true;
            this.cbLiving.Location = new System.Drawing.Point(150, 150);
            this.cbLiving.Name = "cbLiving";
            this.cbLiving.Size = new System.Drawing.Size(200, 21);
            this.cbLiving.TabIndex = 10;
            // 
            // clbWeapons
            // 
            this.clbWeapons.CheckOnClick = true;
            this.clbWeapons.FormattingEnabled = true;
            this.clbWeapons.Location = new System.Drawing.Point(150, 210);
            this.clbWeapons.Name = "clbWeapons";
            this.clbWeapons.Size = new System.Drawing.Size(200, 79);
            this.clbWeapons.TabIndex = 14;
            // 
            // nudCrew
            // 
            this.nudCrew.Location = new System.Drawing.Point(150, 178);
            this.nudCrew.Name = "nudCrew";
            this.nudCrew.Size = new System.Drawing.Size(200, 20);
            this.nudCrew.TabIndex = 12;
            // 
            // btnBuild
            // 
            this.btnBuild.Location = new System.Drawing.Point(370, 42);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.Size = new System.Drawing.Size(170, 30);
            this.btnBuild.TabIndex = 15;
            this.btnBuild.Text = "Зібрати";
            this.btnBuild.UseVisualStyleBackColor = true;
            // 
            // btnPresetAttack
            // 
            this.btnPresetAttack.Location = new System.Drawing.Point(370, 78);
            this.btnPresetAttack.Name = "btnPresetAttack";
            this.btnPresetAttack.Size = new System.Drawing.Size(170, 30);
            this.btnPresetAttack.TabIndex = 16;
            this.btnPresetAttack.Text = "Ударний";
            this.btnPresetAttack.UseVisualStyleBackColor = true;
            // 
            // btnPresetPatrol
            // 
            this.btnPresetPatrol.Location = new System.Drawing.Point(370, 114);
            this.btnPresetPatrol.Name = "btnPresetPatrol";
            this.btnPresetPatrol.Size = new System.Drawing.Size(170, 30);
            this.btnPresetPatrol.TabIndex = 17;
            this.btnPresetPatrol.Text = "Патрульний";
            this.btnPresetPatrol.UseVisualStyleBackColor = true;
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(370, 150);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(170, 30);
            this.btnRandom.TabIndex = 18;
            this.btnRandom.Text = "Випадково заповнити";
            this.btnRandom.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(370, 186);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(170, 30);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Очистити поле";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(16, 305);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutput.Size = new System.Drawing.Size(524, 210);
            this.txtOutput.TabIndex = 20;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 530);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.btnPresetPatrol);
            this.Controls.Add(this.btnPresetAttack);
            this.Controls.Add(this.btnBuild);
            this.Controls.Add(this.clbWeapons);
            this.Controls.Add(this.lblWeapons);
            this.Controls.Add(this.nudCrew);
            this.Controls.Add(this.lblCrew);
            this.Controls.Add(this.cbLiving);
            this.Controls.Add(this.lblLiving);
            this.Controls.Add(this.cbSonar);
            this.Controls.Add(this.lblSonar);
            this.Controls.Add(this.cbPower);
            this.Controls.Add(this.lblPower);
            this.Controls.Add(this.cbPropulsion);
            this.Controls.Add(this.lblPropulsion);
            this.Controls.Add(this.cbHull);
            this.Controls.Add(this.lblHull);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.nudCrew)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
