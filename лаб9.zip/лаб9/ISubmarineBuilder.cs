namespace Lab9
{
    public interface ISubmarineBuilder
    {
        void Reset();
        void SetHull(HullType hull);
        void SetPropulsion(PropulsionType propulsion);
        void SetPowerPlant(PowerPlantType powerPlant);
        void SetSonar(SonarType sonar);
        void SetLivingModule(LivingModuleType module);
        void SetCrew(int crew);
        void AddWeapon(WeaponType weapon);

        Submarine GetResult();
    }
}
