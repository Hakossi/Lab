using System.Text;

namespace _4
{
  
    public class SystemUnit
    {
        public string Name { get; set; }        
        public string Cpu { get; set; }
        public string Gpu { get; set; }
        public int RamGb { get; set; }
        public string Storage { get; set; }       
        public int StorageTotalGb { get; set; } 
        public string Psu { get; set; }
        public string Case { get; set; }
        public bool HasWifi { get; set; }
        public bool HasRgb { get; set; }
        public decimal Price { get; set; }       

        public string GetDetails()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Назва збірки: {Name}");
            sb.AppendLine($"CPU: {Cpu}");
            sb.AppendLine($"GPU: {Gpu}");
            sb.AppendLine($"RAM: {RamGb} ГБ");
            sb.AppendLine($"Накопичувач: {Storage} (усього ~ {StorageTotalGb} ГБ)");
            sb.AppendLine($"Блок живлення: {Psu}");
            sb.AppendLine($"Корпус: {Case}");
            sb.AppendLine($"Wi-Fi модуль: {(HasWifi ? "є" : "немає")}");
            sb.AppendLine($"RGB підсвітка: {(HasRgb ? "є" : "немає")}");
            sb.AppendLine($"Орієнтовна ціна: {Price} грн");
            return sb.ToString();
        }

        public override string ToString()
        {
            return $"{Name} [{Cpu}, {RamGb} ГБ RAM, {Storage}] – {Price} грн";
        }
    }
}
