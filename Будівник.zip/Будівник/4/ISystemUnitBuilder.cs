namespace _4
{
    
    public interface ISystemUnitBuilder
    {
        void Reset();
        void SetName(string name);
        void SetCpu(string cpu);
        void SetGpu(string gpu);
        void SetRam(int ramGb);
        void SetStorage(string storage, int totalGb);
        void SetPsu(string psu);
        void SetCase(string caseName);
        void SetWifi(bool hasWifi);
        void SetRgb(bool hasRgb);
        void SetPrice(decimal price);
        SystemUnit GetResult();
    }
}
