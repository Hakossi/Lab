using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace _4
{
    public partial class Form1 : Form
    {
        // Як студент 4 курсу, тут використовую Builder для зручного конструювання збірок ПК.
        private readonly ISystemUnitBuilder _builder = new BasicSystemUnitBuilder();
        private readonly List<SystemUnit> _systems = new List<SystemUnit>();

        public Form1()
        {
            InitializeComponent();
            InitControls();
        }

        private void InitControls()
        {
            // Шаблони збірок
            comboBoxTemplate.Items.Clear();
            comboBoxTemplate.Items.Add("Офісний ПК");
            comboBoxTemplate.Items.Add("Ігровий ПК");
            comboBoxTemplate.Items.Add("Робоча станція");
            comboBoxTemplate.SelectedIndex = 0;

            // CPU
            comboBoxCpu.Items.Clear();
            comboBoxCpu.Items.Add("Intel Core i3");
            comboBoxCpu.Items.Add("Intel Core i5");
            comboBoxCpu.Items.Add("Intel Core i7");
            comboBoxCpu.Items.Add("AMD Ryzen 5");
            comboBoxCpu.Items.Add("AMD Ryzen 7");
            comboBoxCpu.SelectedIndex = 1;

            // GPU
            comboBoxGpu.Items.Clear();
            comboBoxGpu.Items.Add("Вбудована графіка");
            comboBoxGpu.Items.Add("NVIDIA GTX 1650");
            comboBoxGpu.Items.Add("NVIDIA RTX 3060");
            comboBoxGpu.Items.Add("NVIDIA RTX 4070");
            comboBoxGpu.Items.Add("AMD Radeon RX 6600");
            comboBoxGpu.SelectedIndex = 1;

            // RAM
            numericUpDownRam.Minimum = 4;
            numericUpDownRam.Maximum = 128;
            numericUpDownRam.Value = 16;

            // Storage
            comboBoxStorage.Items.Clear();
            comboBoxStorage.Items.Add("512GB SSD");
            comboBoxStorage.Items.Add("1TB SSD");
            comboBoxStorage.Items.Add("512GB SSD + 1TB HDD");
            comboBoxStorage.Items.Add("2TB SSD");
            comboBoxStorage.SelectedIndex = 0;

            // PSU & Case
            textBoxPsu.Text = "600W 80+ Bronze";
            textBoxCase.Text = "MidiTower ATX";

            // Wi-Fi / RGB
            checkBoxWifi.Checked = true;
            checkBoxRgb.Checked = false;

            // Price
            numericUpDownPrice.Minimum = 10000;
            numericUpDownPrice.Maximum = 200000;
            numericUpDownPrice.Increment = 1000;
            numericUpDownPrice.Value = 25000;

            textBoxName.Text = "Офісний ПК";

            UpdateSummary();
        }

        private void buttonApplyTemplate_Click(object sender, EventArgs e)
        {
            var template = comboBoxTemplate.SelectedItem as string;
            if (string.IsNullOrEmpty(template))
                return;

            if (template == "Офісний ПК")
            {
                textBoxName.Text = "Офісний ПК";
                comboBoxCpu.SelectedItem = "Intel Core i3";
                comboBoxGpu.SelectedItem = "Вбудована графіка";
                numericUpDownRam.Value = 8;
                comboBoxStorage.SelectedItem = "512GB SSD";
                textBoxPsu.Text = "450W 80+ Bronze";
                textBoxCase.Text = "Compact mATX";
                checkBoxWifi.Checked = true;
                checkBoxRgb.Checked = false;
                numericUpDownPrice.Value = 15000;
            }
            else if (template == "Ігровий ПК")
            {
                textBoxName.Text = "Ігровий ПК";
                comboBoxCpu.SelectedItem = "AMD Ryzen 7";
                comboBoxGpu.SelectedItem = "NVIDIA RTX 3060";
                numericUpDownRam.Value = 32;
                comboBoxStorage.SelectedItem = "512GB SSD + 1TB HDD";
                textBoxPsu.Text = "750W 80+ Gold";
                textBoxCase.Text = "Gaming ATX з склом";
                checkBoxWifi.Checked = true;
                checkBoxRgb.Checked = true;
                numericUpDownPrice.Value = 45000;
            }
            else if (template == "Робоча станція")
            {
                textBoxName.Text = "Робоча станція";
                comboBoxCpu.SelectedItem = "Intel Core i7";
                comboBoxGpu.SelectedItem = "NVIDIA RTX 4070";
                numericUpDownRam.Value = 64;
                comboBoxStorage.SelectedItem = "2TB SSD";
                textBoxPsu.Text = "850W 80+ Gold";
                textBoxCase.Text = "Silent ATX";
                checkBoxWifi.Checked = false;
                checkBoxRgb.Checked = false;
                numericUpDownPrice.Value = 70000;
            }
        }

        private void buttonBuild_Click(object sender, EventArgs e)
        {
            // Заповнюємо будівник даними з форми
            _builder.Reset();
            _builder.SetName(textBoxName.Text.Trim());
            _builder.SetCpu(comboBoxCpu.SelectedItem as string ?? "");
            _builder.SetGpu(comboBoxGpu.SelectedItem as string ?? "");
            _builder.SetRam((int)numericUpDownRam.Value);

            var storageText = comboBoxStorage.SelectedItem as string ?? "";
            int storageGb = EstimateStorageGb(storageText);
            _builder.SetStorage(storageText, storageGb);

            _builder.SetPsu(textBoxPsu.Text.Trim());
            _builder.SetCase(textBoxCase.Text.Trim());
            _builder.SetWifi(checkBoxWifi.Checked);
            _builder.SetRgb(checkBoxRgb.Checked);
            _builder.SetPrice(numericUpDownPrice.Value);

            var systemUnit = _builder.GetResult();
            if (string.IsNullOrWhiteSpace(systemUnit.Name))
            {
                systemUnit.Name = "Збірка без назви";
            }

            _systems.Add(systemUnit);
            listBoxSystems.Items.Add(systemUnit);
            UpdateSummary();
        }

        private int EstimateStorageGb(string storageText)
        {
            // Дуже проста логіка, чисто для прикладу.
            // Парсимо всі числа перед "GB" і складаємо.
            int total = 0;
            var parts = storageText.Split(' ');
            foreach (var part in parts)
            {
                if (part.EndsWith("GB", StringComparison.OrdinalIgnoreCase))
                {
                 
                    var numberPart = part.ToUpperInvariant().Replace("GB", "");
                    if (int.TryParse(numberPart, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
                    {
                        total += value;
                    }
                }
            }

            // Якщо щось не розпізналося – ставимо дефолт 512
            if (total == 0)
            {
                total = 512;
            }

            return total;
        }

       

        private void buttonClear_Click(object sender, EventArgs e)
        {
            _systems.Clear();
            listBoxSystems.Items.Clear();
            
            UpdateSummary();
        }

        private void UpdateSummary()
        {
            if (_systems.Count == 0)
            {
                
                return;
            }

            decimal totalPrice = 0;
            foreach (var s in _systems)
            {
                totalPrice += s.Price;
            }

            var sb = new StringBuilder();
            sb.Append("Кількість збірок: ");
            sb.Append(_systems.Count);
            sb.Append(" | Загальна вартість: ");
            sb.Append(totalPrice);
            sb.Append(" грн");

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
