namespace _2
{
    partial class Form1
    {
        /// <summary>
        /// Обов'язкова змінна конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Прибираємо ресурси, коли форма закривається.
        /// </summary>
        /// <param name="disposing">true, якщо керовані ресурси слід видалити; інакше false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, створений конструктором форм Windows

        /// <summary>
        /// Мінімально адекватна розмітка без GroupBox/Panel – чисто форма, кнопки, комбобокси.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelShop = new System.Windows.Forms.Label();
            this.comboBoxShop = new System.Windows.Forms.ComboBox();
            this.labelCoffeeType = new System.Windows.Forms.Label();
            this.comboBoxCoffeeType = new System.Windows.Forms.ComboBox();
            this.labelSize = new System.Windows.Forms.Label();
            this.comboBoxSize = new System.Windows.Forms.ComboBox();
            this.buttonMakeCoffee = new System.Windows.Forms.Button();
            this.buttonClearOrders = new System.Windows.Forms.Button();
            this.labelOrders = new System.Windows.Forms.Label();
            this.listBoxOrders = new System.Windows.Forms.ListBox();
            this.labelDetails = new System.Windows.Forms.Label();
            this.textBoxDetails = new System.Windows.Forms.TextBox();
            this.labelSummary = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelShop
            // 
            this.labelShop.AutoSize = true;
            this.labelShop.Location = new System.Drawing.Point(12, 15);
            this.labelShop.Name = "labelShop";
            this.labelShop.Size = new System.Drawing.Size(55, 13);
            this.labelShop.TabIndex = 0;
            this.labelShop.Text = "Кав\'ярня:";
            // 
            // comboBoxShop
            // 
            this.comboBoxShop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxShop.FormattingEnabled = true;
            this.comboBoxShop.Location = new System.Drawing.Point(76, 12);
            this.comboBoxShop.Name = "comboBoxShop";
            this.comboBoxShop.Size = new System.Drawing.Size(170, 21);
            this.comboBoxShop.TabIndex = 1;
            // 
            // labelCoffeeType
            // 
            this.labelCoffeeType.AutoSize = true;
            this.labelCoffeeType.Location = new System.Drawing.Point(260, 15);
            this.labelCoffeeType.Name = "labelCoffeeType";
            this.labelCoffeeType.Size = new System.Drawing.Size(56, 13);
            this.labelCoffeeType.TabIndex = 2;
            this.labelCoffeeType.Text = "Тип кави:";
            // 
            // comboBoxCoffeeType
            // 
            this.comboBoxCoffeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCoffeeType.FormattingEnabled = true;
            this.comboBoxCoffeeType.Location = new System.Drawing.Point(331, 12);
            this.comboBoxCoffeeType.Name = "comboBoxCoffeeType";
            this.comboBoxCoffeeType.Size = new System.Drawing.Size(140, 21);
            this.comboBoxCoffeeType.TabIndex = 3;
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Location = new System.Drawing.Point(490, 15);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(45, 13);
            this.labelSize.TabIndex = 4;
            this.labelSize.Text = "Розмір:";
            // 
            // comboBoxSize
            // 
            this.comboBoxSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSize.FormattingEnabled = true;
            this.comboBoxSize.Location = new System.Drawing.Point(542, 12);
            this.comboBoxSize.Name = "comboBoxSize";
            this.comboBoxSize.Size = new System.Drawing.Size(100, 21);
            this.comboBoxSize.TabIndex = 5;
            // 
            // buttonMakeCoffee
            // 
            this.buttonMakeCoffee.Location = new System.Drawing.Point(15, 45);
            this.buttonMakeCoffee.Name = "buttonMakeCoffee";
            this.buttonMakeCoffee.Size = new System.Drawing.Size(200, 23);
            this.buttonMakeCoffee.TabIndex = 6;
            this.buttonMakeCoffee.Text = "Заварити каву";
            this.buttonMakeCoffee.UseVisualStyleBackColor = true;
            this.buttonMakeCoffee.Click += new System.EventHandler(this.buttonMakeCoffee_Click);
            // 
            // buttonClearOrders
            // 
            this.buttonClearOrders.Location = new System.Drawing.Point(230, 45);
            this.buttonClearOrders.Name = "buttonClearOrders";
            this.buttonClearOrders.Size = new System.Drawing.Size(200, 23);
            this.buttonClearOrders.TabIndex = 7;
            this.buttonClearOrders.Text = "Очистити замовлення";
            this.buttonClearOrders.UseVisualStyleBackColor = true;
            this.buttonClearOrders.Click += new System.EventHandler(this.buttonClearOrders_Click);
            // 
            // labelOrders
            // 
            this.labelOrders.AutoSize = true;
            this.labelOrders.Location = new System.Drawing.Point(12, 80);
            this.labelOrders.Name = "labelOrders";
            this.labelOrders.Size = new System.Drawing.Size(73, 13);
            this.labelOrders.TabIndex = 8;
            this.labelOrders.Text = "Замовлення:";
            // 
            // listBoxOrders
            // 
            this.listBoxOrders.FormattingEnabled = true;
            this.listBoxOrders.Location = new System.Drawing.Point(15, 100);
            this.listBoxOrders.Name = "listBoxOrders";
            this.listBoxOrders.Size = new System.Drawing.Size(320, 212);
            this.listBoxOrders.TabIndex = 9;
            this.listBoxOrders.SelectedIndexChanged += new System.EventHandler(this.listBoxOrders_SelectedIndexChanged);
            // 
            // labelDetails
            // 
            this.labelDetails.AutoSize = true;
            this.labelDetails.Location = new System.Drawing.Point(350, 80);
            this.labelDetails.Name = "labelDetails";
            this.labelDetails.Size = new System.Drawing.Size(135, 13);
            this.labelDetails.TabIndex = 10;
            this.labelDetails.Text = "Деталі вибраного напою:";
            // 
            // textBoxDetails
            // 
            this.textBoxDetails.Location = new System.Drawing.Point(353, 100);
            this.textBoxDetails.Multiline = true;
            this.textBoxDetails.Name = "textBoxDetails";
            this.textBoxDetails.ReadOnly = true;
            this.textBoxDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDetails.Size = new System.Drawing.Size(289, 212);
            this.textBoxDetails.TabIndex = 11;
            // 
            // labelSummary
            // 
            this.labelSummary.AutoSize = true;
            this.labelSummary.Location = new System.Drawing.Point(12, 330);
            this.labelSummary.Name = "labelSummary";
            this.labelSummary.Size = new System.Drawing.Size(120, 13);
            this.labelSummary.TabIndex = 12;
            this.labelSummary.Text = "Замовлень ще немає.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 361);
            this.Controls.Add(this.labelSummary);
            this.Controls.Add(this.textBoxDetails);
            this.Controls.Add(this.labelDetails);
            this.Controls.Add(this.listBoxOrders);
            this.Controls.Add(this.labelOrders);
            this.Controls.Add(this.buttonClearOrders);
            this.Controls.Add(this.buttonMakeCoffee);
            this.Controls.Add(this.comboBoxSize);
            this.Controls.Add(this.labelSize);
            this.Controls.Add(this.comboBoxCoffeeType);
            this.Controls.Add(this.labelCoffeeType);
            this.Controls.Add(this.comboBoxShop);
            this.Controls.Add(this.labelShop);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelShop;
        private System.Windows.Forms.ComboBox comboBoxShop;
        private System.Windows.Forms.Label labelCoffeeType;
        private System.Windows.Forms.ComboBox comboBoxCoffeeType;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.ComboBox comboBoxSize;
        private System.Windows.Forms.Button buttonMakeCoffee;
        private System.Windows.Forms.Button buttonClearOrders;
        private System.Windows.Forms.Label labelOrders;
        private System.Windows.Forms.ListBox listBoxOrders;
        private System.Windows.Forms.Label labelDetails;
        private System.Windows.Forms.TextBox textBoxDetails;
        private System.Windows.Forms.Label labelSummary;
    }
}
