using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace _2
{
    public partial class Form1 : Form
    {
        // Як студент 4 курсу, просто чесно роблю нормальний приклад фабричного методу :)
        private readonly Dictionary<string, CoffeeShop> _shops =
            new Dictionary<string, CoffeeShop>();

        private readonly List<Coffee> _orders = new List<Coffee>();

        public Form1()
        {
            InitializeComponent();
            InitShops();
            InitControls();
        }

        private void InitShops()
        {
            _shops["Локальна кав'ярня"] = new LocalCoffeeShop();
            _shops["Італійська кав'ярня"] = new ItalianCoffeeShop();
            _shops["Авторська кав'ярня"] = new AuthorCoffeeShop();
        }

        private void InitControls()
        {
            comboBoxShop.Items.Clear();
            comboBoxShop.Items.Add("Локальна кав'ярня");
            comboBoxShop.Items.Add("Італійська кав'ярня");
            comboBoxShop.Items.Add("Авторська кав'ярня");
            comboBoxShop.SelectedIndex = 0;

            comboBoxCoffeeType.Items.Clear();
            comboBoxCoffeeType.Items.Add("Еспресо");
            comboBoxCoffeeType.Items.Add("Американо");
            comboBoxCoffeeType.Items.Add("Лате");
            comboBoxCoffeeType.Items.Add("Капучіно");
            comboBoxCoffeeType.SelectedIndex = 0;

            comboBoxSize.Items.Clear();
            comboBoxSize.Items.Add("Маленька");
            comboBoxSize.Items.Add("Середня");
            comboBoxSize.Items.Add("Велика");
            comboBoxSize.SelectedIndex = 1;

            UpdateSummary();
        }

        private void buttonMakeCoffee_Click(object sender, EventArgs e)
        {
            string shopKey = comboBoxShop.SelectedItem as string;
            string coffeeType = comboBoxCoffeeType.SelectedItem as string;
            string size = comboBoxSize.SelectedItem as string;

            if (string.IsNullOrEmpty(shopKey) || string.IsNullOrEmpty(coffeeType) || string.IsNullOrEmpty(size))
            {
                MessageBox.Show("Оберіть кав'ярню, напій і розмір.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!_shops.TryGetValue(shopKey, out var shop))
            {
                MessageBox.Show("Невідома кав'ярня.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Тут якраз і використовується фабричний метод:
            // конкретна кав'ярня сама вирішує, як створити обраний напій.
            Coffee coffee = shop.OrderCoffee(coffeeType, size);

            _orders.Add(coffee);
            listBoxOrders.Items.Add(coffee);
            UpdateSummary();
        }

        private void listBoxOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxOrders.SelectedItem is Coffee coffee)
            {
                textBoxDetails.Text = coffee.GetDetails();
            }
        }

        private void buttonClearOrders_Click(object sender, EventArgs e)
        {
            _orders.Clear();
            listBoxOrders.Items.Clear();
            textBoxDetails.Clear();
            UpdateSummary();
        }

        private void UpdateSummary()
        {
            if (_orders.Count == 0)
            {
                labelSummary.Text = "Замовлень ще немає.";
                return;
            }

            decimal total = 0;
            foreach (var c in _orders)
            {
                total += c.Price;
            }

            var sb = new StringBuilder();
            sb.Append("Усього напоїв: ");
            sb.Append(_orders.Count);
            sb.Append(" | Сума: ");
            sb.Append(total);
            sb.Append(" грн");

            labelSummary.Text = sb.ToString();
        }
    }
}
