namespace _2
{
  
    public abstract class CoffeeShop
    {
        public abstract string ShopName { get; }

    
        public Coffee OrderCoffee(string coffeeType, string size)
        {
            var coffee = CreateCoffee(coffeeType, size);
            coffee.ShopName = ShopName;
            return coffee;
        }

        protected abstract Coffee CreateCoffee(string coffeeType, string size);
    }
}
