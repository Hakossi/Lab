using System;

namespace _2
{
 
    public class AuthorCoffeeShop : CoffeeShop
    {
        public override string ShopName => "Авторська кав'ярня";

        protected override Coffee CreateCoffee(string coffeeType, string size)
        {
            var coffee = new Coffee
            {
                CoffeeType = coffeeType,
                Size = size
            };

            switch (coffeeType)
            {
                case "Еспресо":
                    coffee.Price = 70;
                    coffee.Strength = 9;
                    coffee.HasMilk = false;
                    coffee.HasFoam = true;   
                    coffee.HasSyrup = false;
                    break;

                case "Американо":
                    coffee.Price = 75;
                    coffee.Strength = 7;
                    coffee.HasMilk = false;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = true;  
                    break;

                case "Лате":
                    coffee.Price = 90;
                    coffee.Strength = 5;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = true;
                    break;

                case "Капучіно":
                    coffee.Price = 90;
                    coffee.Strength = 6;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = true;
                    break;

                default:
                    coffee.Price = 85;
                    coffee.Strength = 6;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = true;
                    break;
            }

            switch (size)
            {
                case "Маленька":
                    break;
                case "Середня":
                    coffee.Price += 15;
                    break;
                case "Велика":
                    coffee.Price += 30;
                    break;
            }

            return coffee;
        }
    }
}
