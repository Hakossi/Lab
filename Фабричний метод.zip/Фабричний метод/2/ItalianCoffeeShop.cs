using System;

namespace _2
{

    public class ItalianCoffeeShop : CoffeeShop
    {
        public override string ShopName => "Італійська кав'ярня";

        protected override Coffee CreateCoffee(string coffeeType, string size)
        {
            var coffee = new Coffee
            {
                CoffeeType = coffeeType,
                Size = size
            };

            switch (coffeeType)
            {
                case "Еспресо":
                    coffee.Price = 65;
                    coffee.Strength = 10;
                    coffee.HasMilk = false;
                    coffee.HasFoam = false;
                    coffee.HasSyrup = false;
                    break;

                case "Американо":
                    coffee.Price = 70;
                    coffee.Strength = 8;
                    coffee.HasMilk = false;
                    coffee.HasFoam = false;
                    coffee.HasSyrup = false;
                    break;

                case "Лате":
                    coffee.Price = 80;
                    coffee.Strength = 6;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = false;
                    break;

                case "Капучіно":
                    coffee.Price = 80;
                    coffee.Strength = 7;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = false;
                    break;

                default:
                    coffee.Price = 75;
                    coffee.Strength = 7;
                    coffee.HasMilk = true;
                    break;
            }

            switch (size)
            {
                case "Маленька":
                    break;
                case "Середня":
                    coffee.Price += 12;
                    break;
                case "Велика":
                    coffee.Price += 25;
                    break;
            }

            return coffee;
        }
    }
}
