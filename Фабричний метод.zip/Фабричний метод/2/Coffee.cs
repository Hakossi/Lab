using System.Text;

namespace _2
{

    public class Coffee
    {
        public string CoffeeType { get; set; }      
        public string Size { get; set; }            
        public string ShopName { get; set; }        
        public decimal Price { get; set; }          
        public int Strength { get; set; }          
        public bool HasMilk { get; set; }
        public bool HasFoam { get; set; }
        public bool HasSyrup { get; set; }

        public string GetDetails()
        {
            var sb = new StringBuilder();
            sb.AppendLine("Кав'ярня: " + ShopName);
            sb.AppendLine("Напій: " + CoffeeType);
            sb.AppendLine("Розмір: " + Size);
            sb.AppendLine("Ціна: " + Price + " грн");
            sb.AppendLine("Міцність (1-10): " + Strength);
            sb.AppendLine("Молоко: " + (HasMilk ? "так" : "ні"));
            sb.AppendLine("Пінка: " + (HasFoam ? "так" : "ні"));
            sb.AppendLine("Сироп: " + (HasSyrup ? "так" : "ні"));
            return sb.ToString();
        }

        public override string ToString()
        {
            return string.Format("{0} {1} ({2}) – {3} грн",
                CoffeeType, Size, ShopName, Price);
        }
    }
}
