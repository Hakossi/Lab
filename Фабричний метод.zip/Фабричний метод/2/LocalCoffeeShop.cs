using System;

namespace _2
{

    public class LocalCoffeeShop : CoffeeShop
    {
        public override string ShopName => "Локальна кав'ярня";

        protected override Coffee CreateCoffee(string coffeeType, string size)
        {
            var coffee = new Coffee
            {
                CoffeeType = coffeeType,
                Size = size
            };

          
            switch (coffeeType)
            {
                case "Еспресо":
                    coffee.Price = 40;
                    coffee.Strength = 9;
                    coffee.HasMilk = false;
                    coffee.HasFoam = false;
                    coffee.HasSyrup = false;
                    break;

                case "Американо":
                    coffee.Price = 45;
                    coffee.Strength = 7;
                    coffee.HasMilk = false;
                    coffee.HasFoam = false;
                    coffee.HasSyrup = false;
                    break;

                case "Лате":
                    coffee.Price = 55;
                    coffee.Strength = 4;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = false;
                    break;

                case "Капучіно":
                    coffee.Price = 55;
                    coffee.Strength = 5;
                    coffee.HasMilk = true;
                    coffee.HasFoam = true;
                    coffee.HasSyrup = false;
                    break;

                default:
                    coffee.Price = 50;
                    coffee.Strength = 5;
                    coffee.HasMilk = true;
                    break;
            }

      
            switch (size)
            {
                case "Маленька":
                  
                    break;
                case "Середня":
                    coffee.Price += 10;
                    break;
                case "Велика":
                    coffee.Price += 20;
                    break;
            }

            return coffee;
        }
    }
}
